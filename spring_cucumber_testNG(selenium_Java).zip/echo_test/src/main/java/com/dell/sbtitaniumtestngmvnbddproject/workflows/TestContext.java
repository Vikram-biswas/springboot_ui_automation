package com.dell.sbtitaniumtestngmvnbddproject.workflows;

import static org.testng.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.apache.hc.core5.util.Asserts;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.ImmutableCapabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.HasDevTools;
import org.openqa.selenium.devtools.v128.log.model.LogEntry;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.Logs;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;
import org.openqa.selenium.remote.http.ClientConfig;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;

import com.dt.echo.fe.ui.page.BaseFactory;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.annotation.LazyConfiguration;
import com.dt.echo.fe.ui.util.config.WebDriverConfig;
import com.google.common.collect.ImmutableMap;

public class TestContext  {
	
	public static WebDriver driver;
	
	public static String featureFilePath = "";
	public static String StartTime = "";
	public static String TagName = "";
	public static String EndTime = "";
	public static String jobId = "";
	public static Properties config = new Properties();
	public static String sessionId = "";
	public static HashMap<String, Object> xrayMapToUpdate = new HashMap<>();
	public static JSONObject xrayConfigJson = null;
	public static int iterationCount = 0;
	public static String xrayEndTime = "";
	public static String xrayStartTime = "";

	public static void InitialConfigurations() {
		try {
			config.load(new FileInputStream("Configuration/Config.properties"));
			CopyExecutableFeatureFiles();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void getChromeDriver(String testName) throws FileNotFoundException, IOException, Exception {
		jobId = System.getProperty("jobId");

		String browserVersion = config.getProperty("BrowserVersion");
		String browserName = config.getProperty("browserName");
		String token = config.getProperty("Token");
		String enableVideo = config.getProperty("EnableVideo");
		String sessionTimeout = config.getProperty("SessionTimeout");
		String proxyType = config.getProperty("proxyType");
		String sslProxy = config.getProperty("sslProxy");
		String httpProxy = config.getProperty("httpProxy");
		String proxyUser = config.getProperty("proxyUser");
		String proxyPassword = config.getProperty("proxyPassword");

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--ignore-certificate-errors");
		options.addArguments("--disable-gpu");
		options.addArguments("--disable-extensions");
		options.addArguments("--disable-notifications");
		options.addArguments("--remote-debugging-port=9222");

		// Set capabilities
		options.setCapability("browserVersion", browserVersion);
		options.setCapability("browserName", browserName);
		options.setCapability("e34:l_testName", testName);
		options.setCapability("e34:token", token);
		options.setCapability("e34:video", enableVideo);
		options.setCapability("e34:per_test_timeout_ms", sessionTimeout);

		// Set proxy configuration
		Map<String, Object> proxy = new HashMap<>();
		proxy.put("proxyType", proxyType);
		proxy.put("sslProxy", sslProxy);
		proxy.put("httpProxy", httpProxy);
		options.setCapability("proxy", proxy);
		options.setCapability("e34:proxyUser", proxyUser);
		options.setCapability("e34:proxyPassword", proxyPassword);
		WebDriver _driver = new ChromeDriver(options);
		driver = _driver;

	}

	public static void getRemoteWebDriver(String testName) throws FileNotFoundException, IOException, Exception {
		jobId = System.getProperty("jobId");

		String sboxURL = config.getProperty("SboxURL");
		String browserVersion = config.getProperty("BrowserVersion");
		String browserName = config.getProperty("browserName");
		String token = config.getProperty("Token");
		String enableVideo = config.getProperty("EnableVideo");
		String sessionTimeout = config.getProperty("SessionTimeout");
		String proxyType = config.getProperty("proxyType");
		String sslProxy = config.getProperty("sslProxy");
		String httpProxy = config.getProperty("httpProxy");
		String proxyUser = config.getProperty("proxyUser");
		String proxyPassword = config.getProperty("proxyPassword");

		try {
			ChromeOptions options = new ChromeOptions();

			// Set capabilities
			options.setCapability("browserVersion", browserVersion);
			options.setCapability("browserName", browserName);
			options.setCapability("e34:l_testName", testName);
			options.setCapability("e34:token", token);
			options.setCapability("e34:video", enableVideo);
			options.setCapability("e34:per_test_timeout_ms", sessionTimeout);

			// Set proxy configuration
			Map<String, Object> proxy = new HashMap<>();
			proxy.put("proxyType", proxyType);
			proxy.put("sslProxy", sslProxy);
			proxy.put("httpProxy", httpProxy);
			options.setCapability("proxy", proxy);
			options.setCapability("e34:proxyUser", proxyUser);
			options.setCapability("e34:proxyPassword", proxyPassword);
			
			RemoteWebDriver _remotedriver = new RemoteWebDriver(URI.create(sboxURL).toURL(), options);
			driver = _remotedriver;
			System.out.println("Current Driver :::: " + driver);
			System.out.println("Remote Driver :::: " + _remotedriver);
			System.out.println("capabilities:" + options.toString());
			System.out.println("Current Driver Session Id : " + ((RemoteWebDriver) driver).getSessionId());
			SessionId sessionId = _remotedriver.getSessionId();
			System.out.println("Remote Driver SessionId :: " + sessionId);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void cleanupWebDriver() throws FileNotFoundException, IOException, Exception {
		driver.quit();
	}

	public static void updateSessionId(String jobId, String name, String sessionId, String startTime, String endTime,
			String testType) {

		File f = new File(jobId + ".txt");
		try {

			if (f.exists()) {
				writeContentsToFile(f, name, sessionId, startTime, endTime, testType);
			} else {
				f.createNewFile();
				writeContentsToFile(f, name, sessionId, startTime, endTime, testType);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void writeContentsToFile(File f, String name, String sessionId, String startTime, String endTime,
			String testType) throws IOException {
		PrintWriter out = new PrintWriter(new FileWriter(f, true));
		try {
			StringBuffer content = new StringBuffer();
			if (testType != null && testType.equalsIgnoreCase("cucumber")) {
				System.out.println(name + " --> " + sessionId + " " + startTime + " " + endTime);
				if (startTime != null && !startTime.equalsIgnoreCase(""))
					content.append(name + " --> " + sessionId + " " + startTime);
				else
					content.append(name + " --> " + sessionId + " "
							+ new SimpleDateFormat("YYYY-MM-dd'T'HH:mm:ss").format(new Date()));
				if (endTime != null && !endTime.equalsIgnoreCase(""))
					content.append(" " + endTime);
				else
					content.append(" " + new SimpleDateFormat("YYYY-MM-dd'T'HH:mm:ss").format(new Date()));
				out.println(content.toString());

			} else {
				System.out.println(name + " --> " + sessionId);
				out.println(name + " --> " + sessionId);
			}
		} finally {
			out.close();
		}
	}

	private static void CopyExecutableFeatureFiles() {
		try {
			String actualFeatureFilePath = null;
			featureFilePath = "target/features";
			actualFeatureFilePath = "Features";

			CreateFolder("target/features");

			File dirPath = new File(actualFeatureFilePath);
			File filesList[] = dirPath.listFiles();
			for (File file : filesList) {
				String featureFileName = file.getName();
				if (featureFileName.endsWith(".feature")) {
					BufferedReader reader = new BufferedReader(
							new FileReader(actualFeatureFilePath + "/" + featureFileName));

					CopyLocalFile(actualFeatureFilePath + "/" + featureFileName,
							featureFilePath + "/" + featureFileName);
					reader.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static boolean CreateFolder(String path) {
		boolean result = false;
		try {
			File file = new File(path);
			result = file.mkdirs();
			System.out.println("Folder created : " + path);
		} catch (Exception e) {
			// Assert.fail(e.getMessage());
		}
		return result;
	}

	public static boolean CopyLocalFile(String source, String destination) {
		boolean result = false;
		try {
			Path sourcePath = Paths.get(source);
			Path destinationPath = Paths.get(destination);

			Files.copy(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception e) {
			// Assert.fail(e.getMessage());
		}
		return result;
	}

	public static void AssignData() {
		try {
			File dirPath = new File(featureFilePath);
			File filesList[] = dirPath.listFiles();
			for (File featureFile : filesList) {
				String _oldfeatureFileContent = "";
				String newfeatureFileContent = "";

				if (featureFile.exists()) {
					BufferedReader reader = new BufferedReader(new FileReader(featureFile));
					String line = reader.readLine();
					while (line != null) {
						_oldfeatureFileContent = _oldfeatureFileContent + line + System.lineSeparator();
						line = reader.readLine();
					}

					if (!_oldfeatureFileContent.equalsIgnoreCase("")) {
						newfeatureFileContent = _oldfeatureFileContent;

						String findString = "| read data from excel |";

						int exampleIndex = _oldfeatureFileContent.toLowerCase().indexOf(findString);

						if (exampleIndex >= 0) {
							String examples = readdatafromexcel("Sheet1");

							if (!examples.equalsIgnoreCase("")) {
								newfeatureFileContent = newfeatureFileContent.replace(findString, examples);
								FileWriter writer = new FileWriter(featureFilePath + "/" + featureFile.getName());
								writer.write(newfeatureFileContent);
								reader.close();
								writer.close();
							}
						} else
							System.out.println("Feature file does not contain the string \"" + findString + "\"");

					} else
						System.out.println("Feature file is empty");
				} else
					System.out.println("Invalid feature file path");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String readdatafromexcel(String tag) {
		String examples = "";

		try {
			String xlsPath = "Data/TestData.xlsx";
			File dataFile = new File(xlsPath);
			if (dataFile.exists()) {
				FileInputStream fis = new FileInputStream(dataFile);
				XSSFWorkbook dataWorkBook = new XSSFWorkbook(fis);
				Iterator<Row> rowIterator = null;
				try {
					XSSFSheet dataSheet = dataWorkBook.getSheet(tag);
					rowIterator = dataSheet.iterator();
				} catch (Exception e) {
					System.out.println("Invalid excel sheet name");
					dataWorkBook.close();
					fis.close();
					return examples;
				}

				int c = 0;
				while (rowIterator.hasNext()) {
					Row row = rowIterator.next();
					Iterator<Cell> cellIterator = row.cellIterator();
					Cell cell = null;

					String temp = " | ";
					while (cellIterator.hasNext()) {
						cell = cellIterator.next();
						String cellValue = getCellValue(cell);

						if (cellValue.equalsIgnoreCase("null"))
							temp = temp + " | ";
						else
							temp = temp + cellValue + " | ";
					}
					String temp1 = temp.replace("|", "").trim();

					if (!temp1.equalsIgnoreCase("")) {
						examples = examples + temp + System.lineSeparator();
					}
				}

				dataWorkBook.close();
				fis.close();
			} else {
				System.out.println("Invalid excel data file path");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return examples;
	}

	private static String getCellValue(Cell cell) {
		String value = "";
		cell.setCellType(Cell.CELL_TYPE_STRING);
		try {
			switch (cell.getCellTypeEnum()) {
			case BOOLEAN:
				value = Boolean.toString(cell.getBooleanCellValue());
				break;
			case STRING:
				value = cell.getRichStringCellValue().getString();
				break;
			case NUMERIC:
				if (DateUtil.isCellDateFormatted(cell)) {
					DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
					value = dateFormat.format(cell.getDateCellValue());
				} else {
					value = Double.toString(cell.getNumericCellValue());
				}
				break;
			case FORMULA:
				value = cell.getCellFormula().toString();
				break;
			case BLANK:
				value = "";
				break;
			default:
				value = "";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;
	}

	public static void SetInitialXRayMapToUpdate() {
		try {
			String temp = GetJSONValue(xrayConfigJson.toJSONString(), "testExecutionKey");
			if (temp != null)
				xrayMapToUpdate.put("testExecutionKey", temp);

			if (System.getenv("SUMMARY") != null)
				xrayMapToUpdate.put("summary", System.getenv("SUMMARY"));
			else
				xrayMapToUpdate.put("summary", GetJSONValue(xrayConfigJson.toJSONString(), "info_summary"));

			if (System.getenv("DESCRIPTION") != null)
				xrayMapToUpdate.put("description", System.getenv("DESCRIPTION"));
			else
				xrayMapToUpdate.put("description", GetJSONValue(xrayConfigJson.toJSONString(), "info_description"));

			if (System.getenv("VERSION") != null)
				xrayMapToUpdate.put("version", System.getenv("VERSION"));
			else
				xrayMapToUpdate.put("version", GetJSONValue(xrayConfigJson.toJSONString(), "info_version"));

			if (System.getenv("REVISION") != null)
				xrayMapToUpdate.put("revision", System.getenv("REVISION"));
			else
				xrayMapToUpdate.put("revision", GetJSONValue(xrayConfigJson.toJSONString(), "info_revision"));

			if (System.getenv("USER") != null)
				xrayMapToUpdate.put("user", System.getenv("USER"));
			else
				xrayMapToUpdate.put("user", GetJSONValue(xrayConfigJson.toJSONString(), "info_user"));

			if (xrayMapToUpdate.get("startDate") == null)
				xrayMapToUpdate.put("startDate", xrayStartTime);

			if (System.getenv("TESTPLANKEY") != null)
				xrayMapToUpdate.put("testPlanKey", System.getenv("TESTPLANKEY"));
			else
				xrayMapToUpdate.put("testPlanKey", GetJSONValue(xrayConfigJson.toJSONString(), "info_testPlanKey"));

			String strTestEnvironments = "";
			if (System.getenv("TESTENVIRONMENTS") != null)
				strTestEnvironments = System.getenv("TESTENVIRONMENTS");
			else {
				strTestEnvironments = GetJSONValue(xrayConfigJson.toJSONString(), "info_testEnvironments");
				strTestEnvironments = strTestEnvironments.replace("[", "").replace("]", "").replace("\"", "");
			}
			String[] arrTestEnvironments = strTestEnvironments.split(",");
			ArrayList<String> testEnvironments = new ArrayList<>();
			for (String env : arrTestEnvironments) {
				if (!env.trim().equalsIgnoreCase(""))
					testEnvironments.add(env);
			}
			xrayMapToUpdate.put("testEnvironments", testEnvironments);

			xrayMapToUpdate.put("testKey", TagName.replace("@", ""));
			xrayMapToUpdate.put("start", xrayStartTime);

			ArrayList<String> examples = new ArrayList<String>();
			if (iterationCount > 0) {
				if (xrayMapToUpdate.get("examples") != null)
					examples = (ArrayList<String>) xrayMapToUpdate.get("examples");
				examples.add("EXECUTING");
			}
			xrayMapToUpdate.put("examples", examples);

			xrayMapToUpdate.put("status", "EXECUTING");

			if (System.getenv("EXECUTEDBY") != null)
				xrayMapToUpdate.put("executedBy", System.getenv("EXECUTEDBY"));
			else
				xrayMapToUpdate.put("executedBy", GetJSONValue(xrayConfigJson.toJSONString(), "tests_0_executedBy"));

			if (System.getenv("ASSIGNEE") != null)
				xrayMapToUpdate.put("assignee", System.getenv("ASSIGNEE"));
			else
				xrayMapToUpdate.put("assignee", GetJSONValue(xrayConfigJson.toJSONString(), "tests_0_assignee"));

			if (System.getenv("COMMENT") != null)
				xrayMapToUpdate.put("comment", System.getenv("COMMENT"));
			else
				xrayMapToUpdate.put("comment", GetJSONValue(xrayConfigJson.toJSONString(), "tests_0_comment"));

			xrayMapToUpdate.put("data", null);
			xrayMapToUpdate.put("filename", null);
			xrayMapToUpdate.put("contentType", null);
			xrayMapToUpdate.put("finishDate", null);
			xrayMapToUpdate.put("finish", null);

			String strDefects = "";
			if (System.getenv("DEFECTS") != null)
				strDefects = System.getenv("DEFECTS");
			else {
				strDefects = GetJSONValue(xrayConfigJson.toJSONString(), "tests_0_defects");
				strDefects = strDefects.replace("[", "").replace("]", "").replace("\"", "");
			}
			String[] arrDefects = strDefects.split(",");
			ArrayList<String> defects = new ArrayList<>();
			for (String def : arrDefects) {
				if (!def.trim().equalsIgnoreCase(""))
					defects.add(def);
			}
			xrayMapToUpdate.put("defects", defects);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//	public static void UpdateXRayTest() {
//		try {
//			APIVerbMethods apiVerbMethods = new APIVerbMethods();
//			
//			xrayConfigJson = SetJSONValue(xrayConfigJson, xrayMapToUpdate);
//
//			String url = ConfigReader.getProp("xrayexecutionapi");
//			String[] requestheaders = { "Authorization", ConfigReader.getProp("authorization")};
//			String response = apiVerbMethods.executePOST(url, null, xrayConfigJson.toJSONString(), requestheaders);
//			xrayMapToUpdate.put("testExecutionKey", GetJSONValue(response, "testExecIssue_key"));
//			System.out.println("XRAY response : " + response);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	public static JSONObject GetXRayJSON() {
		JSONObject jsonObject = null;
		try {
			JSONParser parser = new JSONParser();
			jsonObject = (JSONObject) parser.parse(new FileReader("xrayconfig.json"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonObject;
	}

	public static JSONObject SetJSONValue(JSONObject jsonObject, HashMap<String, Object> mapToUpdate) {
		try {
			jsonObject.keySet().forEach(key -> {
				Object value = jsonObject.get(key);
				if (value instanceof JSONArray) {
					try {
						SetJSONValue((JSONObject) ((JSONArray) value).get(0), mapToUpdate);
					} catch (Exception e) {
						if (mapToUpdate.containsKey(key)) {
							jsonObject.put(key, mapToUpdate.get(key));
						}
					}
				} else if (value instanceof JSONObject) {
					SetJSONValue((JSONObject) value, mapToUpdate);
				} else {
					if (mapToUpdate.containsKey(key)) {
						jsonObject.put(key, mapToUpdate.get(key));
					}
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false, "SetJSONValue method error");
		}
		return jsonObject;
	}

	public static String GetJSONValue(String jsonString, String key) {
		String value = null;
		try {
			if (jsonString == null || jsonString.isEmpty() || jsonString.trim().equalsIgnoreCase("")) {
				return null;
			}
			if (key == null || key.isEmpty() || key.trim().equalsIgnoreCase("")) {
				return null;
			}
			String[] arrayKey = key.split("_");
			for (int i = 0; i <= arrayKey.length - 1; i++) {
				arrayKey[i] = arrayKey[i].replace("(UN)", "_");
			}

			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObject = null;
			int k = 0;
			if (jsonString.trim().charAt(0) == '[') {
				JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
				if (jsonArray.size() <= Integer.parseInt(arrayKey[0]))
					return null;
				jsonObject = (JSONObject) jsonArray.get(Integer.parseInt(arrayKey[0]));
				k++;
			} else {
				jsonObject = (JSONObject) jsonParser.parse(jsonString);
			}
			if (jsonObject.size() <= 0)
				return null;

			for (int i = k; i < arrayKey.length - 1; i++) {
				if (jsonObject.get(arrayKey[i]).toString().trim().charAt(0) == '[') {
					JSONArray ja = (JSONArray) jsonObject.get(arrayKey[i]);
					i++;
					if (ja.size() <= Integer.parseInt(arrayKey[i]))
						return null;
					jsonObject = (JSONObject) ja.get(Integer.parseInt(arrayKey[i]));
				} else {
					jsonObject = (JSONObject) jsonObject.get(arrayKey[i]);
				}
				if (jsonObject.size() <= 0)
					return null;
			}

			if (jsonObject.get(arrayKey[arrayKey.length - 1]) != null)
				value = jsonObject.get(arrayKey[arrayKey.length - 1]).toString();
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false, "GetJSONValue method error");
		}
		return value;
	}

//	public static String GetBase64(String file) {
//        InputStream in = null;
//        byte[] data = null;
//        try {
//            in = new FileInputStream(file);
//            data = new byte[in.available()];
//            in.read(data);
//            in.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        // Base64 Encoding
//        BASE64Encoder encoder = new BASE64Encoder();
//        return encoder.encode(data);
//    }
//	
}
