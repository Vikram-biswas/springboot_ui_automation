package com.dell.sbtitaniumtestngmvnbddproject.workflows;

import static org.testng.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class APIVerbMethods {
	
	public String executePOST(String endpoint, String path, String requestParams, String... requestheaders)
			throws Exception {
		String entireResponse = null;

		try {
			String responseURL = "";
			if (endpoint != null)
				responseURL = endpoint;
			if (path != null)
				responseURL = responseURL + path;

			ignoreSSL();
			URL url = new URL(responseURL);
			System.out.println("POST Request URL : " + responseURL);

			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
			conn.setRequestProperty("Method", "POST");
			if (requestheaders != null) {
				for (int i = 0; i < requestheaders.length; i += 2)
					conn.setRequestProperty(requestheaders[i].toString(), requestheaders[i + 1].toString());
			}

			OutputStream os = conn.getOutputStream();
			os.write(requestParams.toString().getBytes("UTF-8"));
			os.close();

			System.out.println("POST Request JSON payload : " + requestParams.toString());
			int statusCode = conn.getResponseCode();

			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
			StringBuilder response = new StringBuilder();
			String line = null;
			while ((line = br.readLine()) != null) {
				response.append(line + "\n");
			}
			br.close();
			entireResponse = response.toString();

			System.out.println("POST Response Status Code : " + statusCode);
			System.out.println("POST Response : " + entireResponse);
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false, "executePOST method error");
		}
		return entireResponse;
	}

	public void ignoreSSL() throws Exception {
		try {
			// Create a trust manager that does not validate certificate chains
			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				public void checkClientTrusted(X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(X509Certificate[] certs, String authType) {
				}
			} };

			// Install the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			// Create all-trusting host name verifier
			HostnameVerifier allHostsValid = new HostnameVerifier() {
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			};
			// Install the all-trusting host verifier
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false, "ignoreSSL method error");
		}
	}

	public String executeGET(String endpoint, String path, HashMap<String, String> parameter, String... requestheaders)
			throws Exception {
		String entireResponse = null;
		URL url = null;

		try {
			url = GetGETURL(endpoint, path, parameter);
			ignoreSSL();
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json, text/plain");
			if (requestheaders != null) {
				for (int i = 0; i < requestheaders.length; i += 2)
					conn.setRequestProperty(requestheaders[i].toString(), requestheaders[i + 1].toString());
			}
			Reader reader = new InputStreamReader(conn.getInputStream());
			int statusCode = conn.getResponseCode();

			System.out.println("GET Response Status Code : " + statusCode);
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("GET HTTP Error Code : " + statusCode);
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
			StringBuilder response = new StringBuilder();
			String line = null;
			while ((line = br.readLine()) != null) {
				response.append(line + "\n");
			}
			br.close();
			entireResponse = response.toString();

			System.out.println("GET Response : " + entireResponse);
		} catch (FileNotFoundException e) {
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false, "executeGET method error");
		}
		return entireResponse;
	}

	/**
	 * 
	 * @param endpoint
	 * @param path
	 * @param parameter
	 * @return
	 */
	public URL GetGETURL(String endpoint, String path, HashMap<String, String> parameter) throws Exception {
		StringBuilder parmUrl = new StringBuilder();
		URL url = null;

		try {
			if (endpoint != null)
				parmUrl.append(endpoint);
			if (path != null)
				parmUrl.append(path);
			int i = 0;

			if (parameter != null) {
				for (HashMap.Entry<String, String> entry : parameter.entrySet()) {
					String strKey = entry.getKey();
					String strValue = entry.getValue();

					if (i == 0) {
						parmUrl = parmUrl.append("?" + strKey + "=" + strValue);
						i = 1;
					} else {
						parmUrl = parmUrl.append("&" + strKey + "=" + strValue);
					}
				}
			}

			System.out.println("GET Request is : " + parmUrl.toString());

			url = new URL(parmUrl.toString());
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false, "GetURL method error");
		}

		return url;
	}

	public String executeDELETE(String endpoint, String path, HashMap<String, String> parameter,
			String... requestheaders) throws Exception {
		String entireResponse = null;
		URL url = null;

		try {
			url = GetDELETEURL(endpoint, path, parameter);
			ignoreSSL();
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("DELETE");
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.setRequestProperty("charset", "utf-8");
			if (requestheaders != null) {
				for (int i = 0; i < requestheaders.length; i += 2)
					conn.setRequestProperty(requestheaders[i].toString(), requestheaders[i + 1].toString());
			}
			Reader reader = new InputStreamReader(conn.getInputStream());
			int statusCode = conn.getResponseCode();

			System.out.println("DELETE Response Status Code : " + statusCode);
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("DELETE HTTP Error Code : " + statusCode);
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
			StringBuilder response = new StringBuilder();
			String line = null;
			while ((line = br.readLine()) != null) {
				response.append(line + "\n");
			}
			br.close();
			entireResponse = response.toString();

			System.out.println("DELETE Response : " + entireResponse);
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false, "executeDELETE method error");
		}
		return entireResponse;
	}

	/**
	 * 
	 * @param endpoint
	 * @param path
	 * @param parameter
	 * @return
	 */
	public URL GetDELETEURL(String endpoint, String path, HashMap<String, String> parameter) throws Exception {
		StringBuilder parmUrl = new StringBuilder();
		URL url = null;

		try {
			if (endpoint != null)
				parmUrl.append(endpoint);
			if (path != null)
				parmUrl.append(path);
			int i = 0;

			if (parameter != null) {
				for (HashMap.Entry<String, String> entry : parameter.entrySet()) {
					String strKey = entry.getKey();
					String strValue = entry.getValue();

					if (i == 0) {
						parmUrl = parmUrl.append("?" + strKey + "=" + strValue);
						i = 1;
					} else {
						parmUrl = parmUrl.append("&" + strKey + "=" + strValue);
					}
				}
			}

			System.out.println("DELETE Request is : " + parmUrl.toString());

			url = new URL(parmUrl.toString());
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false, "DeleteURL method error");
		}

		return url;
	}

	@SuppressWarnings("resource")
	public String multipartRequest(String urlTo, Map<String, String> parmas, String filepath, String filefield,
			String fileMimeType, String... requestheaders) {
		HttpURLConnection connection = null;
		DataOutputStream outputStream = null;
		InputStream inputStream = null;

		String twoHyphens = "--";
		String boundary = "*****" + Long.toString(System.currentTimeMillis()) + "*****";
		String lineEnd = "\r\n";

		String result = "";

		int bytesRead, bytesAvailable, bufferSize;
		byte[] buffer;
		int maxBufferSize = 1 * 1024 * 1024;

		String[] q = filepath.split("/");
		int idx = q.length - 1;

		try {
			File file = new File(filepath);
			FileInputStream fileInputStream = new FileInputStream(file);

			URL url = new URL(urlTo);
			connection = (HttpURLConnection) url.openConnection();

			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setUseCaches(false);

			connection.setRequestMethod("POST");
			connection.setRequestProperty("Connection", "Keep-Alive");
			connection.setRequestProperty("User-Agent", "Android Multipart HTTP Client 1.0");
			connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
			
			if (requestheaders != null) {
				for (int i = 0; i < requestheaders.length; i += 2)
					connection.setRequestProperty(requestheaders[i].toString(), requestheaders[i + 1].toString());
			}

			outputStream = new DataOutputStream(connection.getOutputStream());
			outputStream.writeBytes(twoHyphens + boundary + lineEnd);
			outputStream.writeBytes("Content-Disposition: form-data; name=\"" + filefield + "\"; filename=\"" + q[idx]
					+ "\"" + lineEnd);
			outputStream.writeBytes("Content-Type: " + fileMimeType + lineEnd);
			outputStream.writeBytes("Content-Transfer-Encoding: binary" + lineEnd);

			outputStream.writeBytes(lineEnd);

			bytesAvailable = fileInputStream.available();
			bufferSize = Math.min(bytesAvailable, maxBufferSize);
			buffer = new byte[bufferSize];

			bytesRead = fileInputStream.read(buffer, 0, bufferSize);
			while (bytesRead > 0) {
				outputStream.write(buffer, 0, bufferSize);
				bytesAvailable = fileInputStream.available();
				bufferSize = Math.min(bytesAvailable, maxBufferSize);
				bytesRead = fileInputStream.read(buffer, 0, bufferSize);
			}

			outputStream.writeBytes(lineEnd);

			// Upload POST Data
			if (parmas != null) {
			Iterator<String> keys = parmas.keySet().iterator();
			while (keys.hasNext()) {
				String key = keys.next();
				String value = parmas.get(key);

				outputStream.writeBytes(twoHyphens + boundary + lineEnd);
				outputStream.writeBytes("Content-Disposition: form-data; name=\"" + key + "\"" + lineEnd);
				outputStream.writeBytes("Content-Type: " + fileMimeType + lineEnd);
				outputStream.writeBytes(lineEnd);
				outputStream.writeBytes(value);
				outputStream.writeBytes(lineEnd);
			}
			}

			outputStream.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

			if (200 != connection.getResponseCode()) {
				throw new Exception("Failed to upload code:" + connection.getResponseCode() + " "
						+ connection.getResponseMessage());
			}

			inputStream = connection.getInputStream();

			result = this.convertStreamToString(inputStream);

			fileInputStream.close();
			inputStream.close();
			outputStream.flush();
			outputStream.close();

		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(false, "DeleteURL method error");
		}
		return result;
	}

	private String convertStreamToString(InputStream is) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return sb.toString();
	}
}
