package com.dt.echo.fe.ui.page.home;

import java.awt.AWTException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.dt.echo.fe.ui.page.BaseFactory;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.annotation.Page;
import com.dt.echo.fe.ui.util.service.CustomActionsService;
import com.dt.echo.fe.ui.util.service.ImageValidationService;
import com.dt.echo.fe.ui.util.service.JavaScriptExecutorService;
import com.dt.echo.fe.ui.util.service.RobotClassService;
import com.dt.echo.fe.ui.util.service.UtilService;

@Page
public class HomePage extends BaseFactory {

	public String pdfUrl;

	@LazyAutowired
	public JavaScriptExecutorService jsExecutor;

	@LazyAutowired
	private CustomActionsService actions;

	@LazyAutowired
	private ImageValidationService imageValidation;

	@LazyAutowired
	private RobotClassService robot;

	@LazyAutowired
	UtilService util;

	@Autowired
	private Environment property;

	public static Map<String, String> urlValidations = new HashMap<>();

	private String headerGSSValue = "//div[@class='mh-top']//a[@data-locale='?']";
	private String footerGSSValue = "//div[@class='ContextualFooter1']//a[@data-locale='?']";
	private String dynamicFooterXpath = "//a[text()='?']";
	private String dynamicXpathWithContainsText = "//div[@class='uc-options-list']//span[contains(text(),'?')]";

	@FindBy(xpath = "//img[contains(@class,'b-error')]")
	private List<WebElement> Brokenimages;
	
	@FindBy(xpath = "//img")
	private List<WebElement> images;

	@FindBy(id = "iframeSurvey")
	private WebElement frame;

	@FindBy(xpath = "//button[@id='noButtonIPDell']")
	private WebElement feedback;

	@FindBy(id = "mh-search-input")
	private WebElement searchBox;

	@FindBy(xpath = "//span[text()='Contact Us & Dell Chat']")
	private WebElement dealsTitle;

	@FindBy(xpath = "//button[@class='email-close-btn']")
	private WebElement dealsCloseButton;

	@FindBy(xpath = "//a[text()='Accept All']")
	private WebElement cookies;

	@FindBy(id = "um-si-label")
	private WebElement signInHover;

	@FindBy(xpath = "//div[@class='mh-myaccount-unauth-dropdown']//a[@role='button'][1]")
	private WebElement signInButton;

	@FindBy(xpath = "//div[@class='mh-myaccount-second-column']//a[@role='button'][1]")
	private WebElement signOutButton;

	@FindBy(xpath = "//button[@id='floating-button']")
	private WebElement floatingContactUs;

	@FindBy(xpath = "(//span[@class='mh-label'])[1]")
	private WebElement headerGSS;

	@FindBy(xpath = "(//span[@class='mh-label'])[2]")
	private WebElement footerGSS;

	@FindBy(xpath = "(//span[text()='Contact Us']//ancestor::a)[1]")
	private WebElement contactUs;

	@FindBy(xpath = "//h1/span[contains(text(),'Contact Us')]")
	private WebElement contactUsHeader;

	@FindBy(xpath = "(//a[@title='Close'])[2]")
	public WebElement closeVideo;

	@FindBy(xpath = "//div[@class='vjs-errors-ok-button-container']/following-sibling::div[1][@title='Close Modal Dialog']")
	public List<WebElement> closeModalDialog;

	public WebElement dynamicXpathWithContainsText(String text) {
		return driver.findElement(By.xpath(dynamicXpathWithContainsText.replace("?", text)));
	}

	public WebElement dynamicHeaderGssValue(String text) {
		return driver.findElement(By.xpath(headerGSSValue.replace("?", text)));
	}

	public WebElement dynamicFooterGssValue(String text) {
		return driver.findElement(By.xpath(footerGSSValue.replace("?", text)));
	}

	public List<WebElement> dynamicFooterXpath(String text) {
		return driver.findElements(By.xpath(dynamicFooterXpath.replace("?", text)));
	}

	public void pageScrollToElement(WebElement element) {
		this.jsExecutor.pageScrollToElement(element);
	}

	public void signIn() {
		this.wait.until(ExpectedConditions.elementToBeClickable(signInHover));
		jsExecutor.forceMouseHoverAndClick(signInHover, signInButton);
	}

	public void signOut() {
		this.wait.until(ExpectedConditions.elementToBeClickable(signInHover));
		jsExecutor.forceMouseHoverAndClick(signInHover, signOutButton);
	}

	public void contactUs() {
		isFeedbackPresent();
		jsExecutor.forceClick(contactUs);
		isFeedbackPresent();
		this.contactUsHeader.isDisplayed();
	}

	public void pageScrolldown() {
		this.jsExecutor.pageScrollBottom();
	}

	public void pageScrollup() {
		this.jsExecutor.pageScrollUp();
	}

	public void floatingContactUs() {
		this.wait.until(ExpectedConditions.elementToBeClickable(floatingContactUs));
		jsExecutor.forceClick(floatingContactUs);
	}

	public void gss(String gssPoistion, String gssValue) {
		if (gssPoistion.equalsIgnoreCase("header")) {
			actions.mouseHover(headerGSS).click(dynamicHeaderGssValue(gssValue));
		} else {
			this.footerGSS.click();
			dynamicFooterGssValue(gssValue).click();
		}

	}

	public void isDealsPresent() {
		try {
			this.wait.until(ExpectedConditions.elementToBeClickable(dealsTitle));
			if (this.dealsTitle.isDisplayed()) {
				jsExecutor.forceClick(dealsCloseButton);
			}
		} catch (Exception e) {
			// do nothing
		}
	}

	public boolean ifCookies() {
		try {
			this.wait.until(ExpectedConditions.elementToBeClickable(cookies));
			this.cookies.click();
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	public Pair<Boolean, List<String>> validateIfImagesAreBroken() {
		Pair<Boolean, List<String>> pair = null;
		pair = this.imageValidation.findBrokenImage(Brokenimages);
		return pair;
	}

	public void searchBox(String value) throws InterruptedException, AWTException {
		searchBox.sendKeys(value);
		// this.jsExecutor.forceSendKeys(searchBox, value);
		Thread.sleep(2000);
		this.robot.pressEnter();
	}

	public String getCurrentUrl() {
		return driver.getCurrentUrl().toString();
	}

	public void navigateBack() {
		driver.navigate().back();
	}

	public void refreshPage() {
		driver.navigate().refresh();
	}

	public void navigateToNewsRoom() throws UnsupportedEncodingException {
		driver.navigate().to(this.util.handleBasicAuth(property.getProperty("application.stg.authUrl"),
				property.getProperty("application.username"), property.getProperty("application.password")));
	}

	public boolean isFeedbackPresent() {
		boolean flag = false;
		try {
			this.wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame));
			feedback.click();
			driver.switchTo().defaultContent();
			return flag = true;
		} catch (Exception e) {
			return flag;
		}

	}

	public boolean isModalErrorPresent() {
		boolean flag = false;
		try {
			this.wait.until(ExpectedConditions.elementToBeClickable(closeModalDialog.get(0)));
			if (closeModalDialog.size() >= 1) {
				closeModalDialog.forEach(element -> {
					element.click();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				});
				return flag = true;
			} else {
				return flag = false;
			}
		} catch (Exception e) {
			return flag;
		}

	}

	public Pair<List<String>, List<Integer>> urlValidation() {
		List<String> errorUrls = new ArrayList<>();
		List<Integer> statusCode = new ArrayList<>();
		Set<String> urls = urlValidations.keySet();

		urls.forEach(url -> {
			if (url.startsWith("https:")) {
				driver.navigate().to(url);
			} else {
				driver.navigate().to("https:" + url);
			}
			if (util.getUrlStatus(driver.getCurrentUrl()) != 200
					&& util.getUrlStatus(driver.getCurrentUrl()) != 401) {
				errorUrls.add(url);
				statusCode.add(util.getUrlStatus(driver.getCurrentUrl()));
			}
		});
		return Pair.of(errorUrls, statusCode);
	}

	public void validateVideoPlay(WebElement element) throws InterruptedException {
		isModalErrorPresent();
		this.wait.until(ele -> element.isDisplayed());
		element.click();
		WebElement video = wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("video")));
		Thread.sleep(5000);
		jsExecutor.playVideo(video);
		Thread.sleep(5000);
		if (jsExecutor.isVideoPlaying(video)) {
			jsExecutor.pauseVideo(video);
		}
		Thread.sleep(5000);
		System.out.println("forth");
		closeVideo.click();
		System.out.println("closed");
	}

}
