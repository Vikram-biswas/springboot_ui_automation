package com.dt.echo.fe.ui.util.service;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class AlertSwitchService {

	@Autowired
	private ApplicationContext ctx;

	public boolean isAlertPresent() {
		try {
			WebDriver driver = this.ctx.getBean(WebDriver.class);
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	public void alertAccept() {
		WebDriver driver = this.ctx.getBean(WebDriver.class);
		Alert alert = driver.switchTo().alert();
		alert.accept();
	}

	public void alertDismiss() {
		WebDriver driver = this.ctx.getBean(WebDriver.class);
		Alert alert = driver.switchTo().alert();
		alert.dismiss();
	}

	public String alertGetText() {
		WebDriver driver = this.ctx.getBean(WebDriver.class);
		Alert alert = driver.switchTo().alert();
		return alert.getText().toString();

	}

	public void alertSendText(String text) {
		WebDriver driver = this.ctx.getBean(WebDriver.class);
		Alert alert = driver.switchTo().alert();
		alert.sendKeys(text);
	}

}
