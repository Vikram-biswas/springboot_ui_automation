package com.dt.echo.fe.ui.util.service;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.springframework.stereotype.Service;

@Service
public class BreakpointService {

	public void setResolution(WebDriver driver, String dimension) {

		Map<String, Dimension> resolutions = new HashMap<>();
		resolutions.put("desktop", new Dimension(1920, 1080));
		resolutions.put("tablet", new Dimension(768, 1024));
		resolutions.put("mobile", new Dimension(375, 667));

		for (Map.Entry<String, Dimension> entry : resolutions.entrySet()) {
			String resolutionName = entry.getKey();
			Dimension windowSize = entry.getValue();

			if (resolutionName.equalsIgnoreCase(dimension)) {
				driver.manage().window().setSize(windowSize);
			}
		}
	}
	
	
	
}
