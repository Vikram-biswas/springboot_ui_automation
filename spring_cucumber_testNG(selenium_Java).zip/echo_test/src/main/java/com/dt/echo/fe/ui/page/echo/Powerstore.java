package com.dt.echo.fe.ui.page.echo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.imaging.ImageReadException;
import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.dt.echo.fe.ui.page.BaseFactory;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.annotation.Page;
import com.dt.echo.fe.ui.util.service.CustomActionsService;
import com.dt.echo.fe.ui.util.service.ImageValidationService;
import com.dt.echo.fe.ui.util.service.JavaScriptExecutorService;
import com.dt.echo.fe.ui.util.service.UtilService;
import com.dt.echo.fe.ui.util.service.WindowSwitchService;

@Page
public class Powerstore extends BaseFactory {

	@LazyAutowired
	public JavaScriptExecutorService jsExecutor;

	@LazyAutowired
	private CustomActionsService actions;

	@LazyAutowired
	private WindowSwitchService window;

	@LazyAutowired
	private ImageValidationService imageValidation;

	@LazyAutowired
	UtilService util;

	@LazyAutowired
	private BasePage base;

	@FindBy(xpath = "//div[@class='header-gss']/a")
	private WebElement headerGss;

	@FindBy(xpath = "//ul[@class='footer-gss']//a")
	private WebElement footerGss;

	@FindBy(xpath = "//ul[@class='footer-gss']//a//span[2]")
	private WebElement footerGssCountry;

	@FindBy(xpath = "//div[@class='gss11-tabs-regions']/a[1]")
	private List<WebElement> GssregionDesktop;

	@FindBy(css = ".gss11-heading +ul > :nth-child(1)")
	private List<WebElement> GssregionMobile;

	@FindBy(xpath = "//span[@class='logo-text']")
	private WebElement logoText;

	@FindBy(xpath = "//a[@class='item']")
	private WebElement localeRegion;

	@FindBy(xpath = "//a[@class='login-box']")
	private WebElement powerStorelogin;

	@FindBy(xpath = "//a[@title='PowerStore']")
	private WebElement powerStoreTitle;

	@FindBy(xpath = "//h1[@class='subheading']")
	private WebElement powerStoreHeader;

	@FindBy(xpath = "//ul[@class='nav-list']/li/a")
	private List<WebElement> navList;

	@FindBy(xpath = "//a[contains(@href,'https://')]")
	private List<WebElement> pageHyperlinksPROD;
	
	@FindBy(xpath = "//a[contains(@href,'https://')][contains(@class,'dt-o-button')]")
	private List<WebElement> pageHyperlinks;

	@FindBy(xpath = "//img")
	private List<WebElement> images;
	
	@FindBy(xpath = "//picture")
	private List<WebElement> screenshot;
	

	String rowLocale = "//a[@data-locale='?']";

	public List<String> headerRegionValidation(String resolution) {
		List<String> headerLocales = new ArrayList<String>();
		Assert.assertEquals(headerGss.getAttribute("data-locale").contains("en-au"), true);
		headerLocales.add(headerGss.getAttribute("data-locale"));
		if (resolution.equalsIgnoreCase("desktop")) {
			Assert.assertEquals(localeRegion.getText().trim().toLowerCase().contains("en"), true);
			headerLocales.add(localeRegion.getText().trim());
		}
		return headerLocales;
	}

	public List<String> footerRegionValidation() {
		List<String> footerLocales = new ArrayList<String>();
		Assert.assertEquals(footerGss.getAttribute("data-locale").contains("en-au"), true);
		footerLocales.add(footerGss.getAttribute("data-locale"));
		Assert.assertEquals(footerGssCountry.getText().trim().contains("Australia"), true);
		footerLocales.add(footerGssCountry.getText().trim());
		return footerLocales;
	}

	public List<String> gssValidation(String gssPoistion, String gssValue) throws InterruptedException {
		List<String> localeCheck = new ArrayList<String>();

		if (gssPoistion.equalsIgnoreCase("header")) {

			wait.until(ExpectedConditions.elementToBeClickable(headerGss));
			actions.click(headerGss);
			Thread.sleep(1000);
			if (GssregionDesktop.size() >= 1) {
				if (!GssregionDesktop.get(0).getAttribute("class").contains("gss11-active")) {
					actions.click(GssregionDesktop.get(0));
				}
			} else if (GssregionMobile.size() >= 1) {
				if (!GssregionMobile.get(0).getAttribute("class").contains("gss11-active")) {
					driver.findElement(By.cssSelector(".gss11-heading +ul > :nth-child(1) > a")).click();
				}
			}

			WebElement element = wait
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath(rowLocale.replace("?", gssValue))));
			element.click();
			Thread.sleep(3000);
			localeCheck.add(headerGss.getAttribute("data-locale"));
			localeCheck.add(localeRegion.getText().trim().toLowerCase());

		} else {

			wait.until(ExpectedConditions.elementToBeClickable(footerGss));
			actions.click(footerGss);
			Thread.sleep(1000);
			if (GssregionDesktop.size() >= 1) {
				if (!GssregionDesktop.get(0).getAttribute("class").contains("gss11-active")) {
					actions.click(GssregionDesktop.get(0));
				}
			} else if (GssregionMobile.size() >= 1) {
				if (!GssregionMobile.get(0).getAttribute("class").contains("gss11-active")) {
					driver.findElement(By.cssSelector(".gss11-heading +ul > :nth-child(1) > a")).click();
				}
			}
			WebElement element = wait
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath(rowLocale.replace("?", gssValue))));
			element.click();
			Thread.sleep(3000);
			localeCheck.add(footerGss.getAttribute("data-locale"));
			localeCheck.add(localeRegion.getText().trim().toLowerCase());

		}

		return localeCheck;

	}

	public Pair<List<String>, List<Integer>> subNavValidation() {

		List<String> urls = new ArrayList<String>();
		List<Integer> statusCodes = new ArrayList<Integer>();

		navList.forEach(element -> {
			try {
				Thread.sleep(1000);
				if (!element.getAttribute("title").contains("PowerStore")) {
					element.click();
					Thread.sleep(1000);
					urls.add(driver.getCurrentUrl());
					statusCodes.add(util.getUrlStatus(driver.getCurrentUrl()));
					driver.navigate().back();
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		});
		return Pair.of(urls, statusCodes);

	}

	public Pair<List<String>, List<Integer>> hyperlinksValidation() {

		List<String> urls = new ArrayList<String>();
		List<Integer> statusCodes = new ArrayList<Integer>();
		
		pageHyperlinks.forEach(element -> {
			try {
				Thread.sleep(1000);
				if (element.getAttribute("href").contains("www.")) {
					element.click();
					Thread.sleep(1000);
					urls.add(driver.getCurrentUrl());
					statusCodes.add(util.getUrlStatus(driver.getCurrentUrl()));
					driver.navigate().back();
				} else if (element.getAttribute("href").contains("dell.")) {
					element.click();
					Thread.sleep(1000);
					window.switchByIndex(1);
					urls.add(driver.getCurrentUrl());
					statusCodes.add(util.getUrlStatus(driver.getCurrentUrl()));
					window.closeWindow(1);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		});
		return Pair.of(urls, statusCodes);

	}

	public String logoText() {
		return logoText.getText();
	}

	public String subnavHeader() {
		return powerStoreHeader.getText();
	}

	public boolean subnavTitle() {
		try {
			powerStoreTitle.getDomAttribute("href").contains("test");
			return false;
		} catch (Exception e) {
			return true;
		}

	}

	public void powerstoreVideoPlay() throws InterruptedException {
		base.validateVideoPlay();
	}

	public Pair<List<String>, List<String>> getImageUrls() throws ImageReadException, IOException {
		Pair<List<String>, List<String>> urls = null;
		urls = this.imageValidation.findImageUrls(images, "dt-o-image", "dt-o-icon");
		this.imageValidation.getScreenshot(screenshot);
		return urls;
	}

	public boolean isElementDisplayed(WebElement element) {
		try {
			element.isDisplayed();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

}
