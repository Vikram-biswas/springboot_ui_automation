package com.dt.echo.fe.ui.page;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;

import com.dell.sbtitaniumtestngmvnbddproject.workflows.TestContext;

import jakarta.annotation.PostConstruct;

public abstract class BaseFactory extends TestContext{
	
	@Autowired
	protected WebDriverWait wait;
	
	@SuppressWarnings("static-access")
	@PostConstruct
	private void init() {
		PageFactory.initElements(this.driver, this);
	}

}
