package com.dt.echo.fe.ui.util.service;

import java.lang.reflect.InvocationTargetException;
import java.util.Optional;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.HasDevTools;
import org.openqa.selenium.devtools.v128.network.Network;
import org.openqa.selenium.remote.Augmenter;
import org.springframework.stereotype.Service;

import com.dell.sbtitaniumtestngmvnbddproject.workflows.TestContext;

@Service
public class DevToolsService {

	private DevTools devTools;


	public void init() {
		TestContext.driver = new Augmenter().augment(TestContext.driver);
		devTools = ((HasDevTools) TestContext.driver).getDevTools();
		devTools.createSession();
	}

	public void networkCallLoads(WebDriver driver) throws SecurityException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException {
		init();
		this.devTools.send(Network.enable(Optional.of(100000), Optional.of(100000), Optional.of(100000)));
		this.devTools.addListener(Network.responseReceived(), response -> {
//			System.out.println("Received Response: " + response.getResponse().getUrl());
//			System.out.println("Status: " + response.getResponse().getStatus());
		});

		this.devTools.addListener(Network.requestWillBeSent(), request -> {
//			System.out.println("Request Sent: " + request.getRequest().getUrl());
		});

	}

	public void getNetWorkCallResponse(String apiURL) {

	}

	public void deviceView(String device) {

	}

}
