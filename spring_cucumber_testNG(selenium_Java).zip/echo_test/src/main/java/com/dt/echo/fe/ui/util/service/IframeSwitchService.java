package com.dt.echo.fe.ui.util.service;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class IframeSwitchService {

	@Autowired
	private ApplicationContext ctx;
	private WebDriver driver;

	public void switchToIframeByIndex(int index) {
		this.driver = this.ctx.getBean(WebDriver.class);
		driver.switchTo().frame(index);
	}

	public void switchToIframe(String element) {
		this.driver = this.ctx.getBean(WebDriver.class);
		driver.switchTo().frame(element);
	}
	
	public void switchToIframe(WebElement element) {
		this.driver = this.ctx.getBean(WebDriver.class);
		driver.switchTo().frame(element);
	}

	public void clickElement(WebElement element) {
		element.click();
	}

	public void getTextElement(WebElement element) {
		element.getText();
	}

	public void getTagNameElement(WebElement element) {
		element.getTagName();
	}
	
	public void getTagNamesElement(List<WebElement> element) {
		element.forEach(val-> val.getTagName());
	}

	public void sendValueElement(WebElement element, String value) {
		element.sendKeys(value);
	}

	public IframeSwitchService switchIframeByIndex(int iframeIndex) {
		switchToIframeByIndex(iframeIndex);
		return this;
	}

	public IframeSwitchService switchIframe(String iframe) {
		switchToIframe(iframe);
		return this;
	}
	
	public IframeSwitchService switchIframe(WebElement iframe) {
		switchToIframe(iframe);
		return this;
	}

	public IframeSwitchService click(WebElement element) {
		clickElement(element);
		return this;
	}

	public IframeSwitchService getText(WebElement element) {
		getTextElement(element);
		return this;
	}

	public IframeSwitchService getTagName(WebElement element) {
		getTagNameElement(element);
		return this;
	}
	
	public IframeSwitchService getTagNames(List<WebElement> element) {
		getTagNamesElement(element);
		return this;
	}

	public IframeSwitchService sendValue(WebElement element, String value) {
		sendValueElement(element, value);
		return this;
	}

}
