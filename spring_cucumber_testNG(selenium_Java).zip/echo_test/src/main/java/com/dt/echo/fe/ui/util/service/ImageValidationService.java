package com.dt.echo.fe.ui.util.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.imaging.ImageReadException;
import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.WebElement;
import org.springframework.stereotype.Service;

import com.dt.echo.fe.ui.util.annotation.LazyAutowired;

@Service
public class ImageValidationService {
	
	@LazyAutowired
	private ScreenshotService screenshotService;

	public Pair<Boolean, List<String>> findBrokenImage(List<WebElement> element) {
		List<String> brokenImages = new ArrayList<>();
		boolean isImageBroken = false;
		if (element != null) {
			for (WebElement image : element) {
				isImageBroken = true;
				brokenImages.add(image.getAttribute("src"));
			}
		}
		return Pair.of(isImageBroken, brokenImages);
	}

	public Pair<List<String>, List<String>> findImageUrls(List<WebElement> allImages, String mediaImage,
			String iconImage) throws ImageReadException, IOException {
		List<String> imageUrls = new ArrayList<>();
		List<String> iconUrls = new ArrayList<>();
		if (allImages != null) {
			for (WebElement image : allImages) {
				screenshotService.getScreenshot(image, "", "");
				if (image.getAttribute("class").contains(mediaImage)) {
					imageUrls.add(image.getAttribute("src"));
				} else if (image.getAttribute("class").contains(iconImage))
					iconUrls.add(image.getAttribute("src"));
			}
		}

		return Pair.of(imageUrls, iconUrls);

	}
	
	public void getScreenshot(List<WebElement> allImages) throws ImageReadException, IOException {
		if (allImages != null) {
			for (WebElement image : allImages) {
				System.out.println(image.getCssValue("width") + " : " + image.getCssValue("height") + "  : " + image.getCssValue("padding"));
				screenshotService.getScreenshot(image, "", "");
		}
		}
	}
}
