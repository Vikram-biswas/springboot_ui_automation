package com.dt.echo.fe.ui.util.service;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import org.springframework.stereotype.Service;

@Service
public class RobotClassService {

	private Robot robot;
	static {
		System.setProperty("java.awt.headless", "false");
	}

	public void pressEnter() throws AWTException {
		robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}

	public void pressTab() throws AWTException {
		robot = new Robot();
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
	}
	
	public void altF4() throws AWTException {
		robot = new Robot();
		robot.setAutoDelay(3000); // Adjust delay as needed

        // Simulate pressing Alt + F4 to close the active window
        // This combination usually closes the currently focused window
        robot.keyPress(KeyEvent.VK_ALT);
        robot.keyPress(KeyEvent.VK_F4);
        robot.keyRelease(KeyEvent.VK_F4);
        robot.keyRelease(KeyEvent.VK_ALT);
	}

}
