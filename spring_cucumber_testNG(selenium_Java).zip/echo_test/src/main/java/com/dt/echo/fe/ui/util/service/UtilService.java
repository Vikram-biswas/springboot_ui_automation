package com.dt.echo.fe.ui.util.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dt.echo.fe.ui.util.config.FakerConfig;

@Service
public class UtilService {

	@Autowired
	private FakerConfig faker;

	public String screenshotName() {
		return "screenshot_" + new Date().getTime() + ".png";
	}

	public void deleteExistingScreenShots(String filePath) {
		try {
			FileUtils.cleanDirectory(Paths.get(System.getProperty("user.dir") + filePath).toFile());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String handleBasicAuth(String url, String username, String password) throws UnsupportedEncodingException {
		return url.replace("username", URLEncoder.encode(username, "UTF-8")).replace("password",
				URLEncoder.encode(password, "UTF-8"));
	}

	public int getUrlStatus(String urlString) {
		try {
			URL url = new URL(urlString);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
			connection.connect();
			return connection.getResponseCode();
		} catch (Exception e) {
			return -1;
		}

	}

	public String currentDate() {
		LocalDate date = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy");
		return date.format(formatter);
	}

	public String pastMonth(int month) {
		LocalDate date = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy");
		return date.minusMonths(month).format(formatter);
	}

	public String pastDate(int day) {
		LocalDate date = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy");
		return date.minusDays(day).format(formatter);
	}

	public String formSubmittion(String value) {
		String data = null;
		switch (value) {
		case "firstName":
			data = faker.getFaker().name().firstName();
			break;
		case "lastName":
			data = faker.getFaker().name().lastName();
			break;
		case "email":
			data = faker.getFaker().internet().emailAddress();
			break;
		case "phoneNumber":
			data = faker.getFaker().number().digits(10);
			break;
		case "companyName":
			data = faker.getFaker().company().industry();
			break;
		case "title":
			data = faker.getFaker().lorem().fixedString(5);
			break;	
		default:
			break;
		}

		return data;
	}
	
	public String formSubmittionInvalidInputs(String value) {
		String data = null;
		switch (value) {
		case "firstName":
			data = faker.getFaker().name().firstName() + "@";
			break;
		case "lastName":
			data = faker.getFaker().name().lastName() + "@";
			break;
		case "email":
			data = faker.getFaker().name().lastName();
			break;
		case "phoneNumber":
			data = faker.getFaker().number().digits(3);
			break;
		case "companyName":
			data = faker.getFaker().number().digits(1);
			break;
		case "title":
			data = faker.getFaker().lorem().fixedString(1);
			break;	
		default:
			break;
		}
		return data;
	}
	
	public String formSubmittionRestrictedInputs(String value) {
		String data = null;
		switch (value) {
		case "firstName":
			data = "test";
			break;
		case "lastName":
			data = "test";
			break;
		case "email":
			data = "test@test.com";
			break;
		case "companyName":
			data = "test";
			break;
		case "title":
			data = "test";
			break;	
		default:
			break;
		}
		return data;
	}

}
