package com.dt.echo.fe.ui.util.service;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class CustomActionsService {

	@Autowired
	private ApplicationContext ctx;
	private Actions actions;
	private WebDriver driver;

	public void mouseHoverElement(WebElement element) {
		this.driver = this.ctx.getBean(WebDriver.class);
		this.actions = new Actions(driver);
		actions.moveToElement(element).perform();
	}

	public void clickElement(WebElement element) {
		this.driver = this.ctx.getBean(WebDriver.class);
		this.actions = new Actions(driver);
		element.click();
	}

	public CustomActionsService mouseHover(WebElement element) {
		mouseHoverElement(element);
		return this;
	}

	public CustomActionsService click(WebElement element) {
		clickElement(element);
		return this;
	}
	
	

}
