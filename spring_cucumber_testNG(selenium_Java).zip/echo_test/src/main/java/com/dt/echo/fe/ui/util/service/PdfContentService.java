package com.dt.echo.fe.ui.util.service;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import org.apache.commons.lang3.tuple.Pair;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Service;

@Service
public class PdfContentService {

	public Pair<Integer, String> getPdfContent(String url) {
		int noOfPages = 0;
		String pdfContentText = null;
		InputStream is = null;
		BufferedInputStream bis = null;
		PDDocument doc = null;

		try {
			// Open the PDF file from the URL
			URL pdfUrl = new URL(url);
			is = pdfUrl.openStream();
			bis = new BufferedInputStream(is);
			doc = PDDocument.load(bis);

			// Extract number of pages and text
			noOfPages = doc.getNumberOfPages();
			PDFTextStripper strip = new PDFTextStripper();
			strip.setStartPage(1);
			strip.setEndPage(1);
			pdfContentText = strip.getText(doc);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// Ensure all resources are closed properly
			try {
				if (doc != null) {
					doc.close();
				}
				if (bis != null) {
					bis.close();
				}
				if (is != null) {
					is.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return Pair.of(noOfPages, pdfContentText);
	}
	
	public boolean validateTextInPdf(String pdfContent, String text) {
		return pdfContent.contains(text);
	}
	

}
