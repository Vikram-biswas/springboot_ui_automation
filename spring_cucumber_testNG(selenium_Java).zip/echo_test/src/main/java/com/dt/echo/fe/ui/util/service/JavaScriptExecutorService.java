package com.dt.echo.fe.ui.util.service;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class JavaScriptExecutorService {
	
	@Autowired
	private ApplicationContext ctx;
	
	public void pageScrollBottom() {
		WebDriver driver = this.ctx.getBean(WebDriver.class);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		int i = 0;
		try {
			while (i < 15) {
				js.executeScript("window.scrollBy(0, 500)");
				Thread.sleep(1000);
				i++;
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void pageScrollUp() {
		WebDriver driver = this.ctx.getBean(WebDriver.class);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
			js.executeScript("window.scrollTo(0, 0);");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void pageScrollToElement(WebElement element) {
		WebDriver driver = this.ctx.getBean(WebDriver.class);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
			js.executeScript("arguments[0].scrollIntoView(true);", element);
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public void forceClick(WebElement element) {
		WebDriver driver = this.ctx.getBean(WebDriver.class);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
			js.executeScript("arguments[0].click();", element);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void forceMouseHoverAndClick(WebElement hoverElement, WebElement clickElement) {
		WebDriver driver = this.ctx.getBean(WebDriver.class);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
			String script = "var hoverElement = arguments[0];" + "var clickElement = arguments[1];"
					+ "var mouseEvent = document.createEvent('MouseEvents');"
					+ "mouseEvent.initEvent('mouseover', true, true);" + "hoverElement.dispatchEvent(mouseEvent);"
					+ "clickElement.click();";
			js.executeScript(script, hoverElement, clickElement);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void forceSendKeys(WebElement element, String sendKeyValue) {
		WebDriver driver = this.ctx.getBean(WebDriver.class);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		try {
			js.executeScript("arguments[0].focus();", element);
			js.executeScript("arguments[0].value = \'" + sendKeyValue + "\';", element);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public String jsExecutorGetAttributeValue(WebElement element, String AttributeName) {
		WebDriver driver = this.ctx.getBean(WebDriver.class);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		return (String) js.executeScript("return arguments[0].getAttribute(\'" + AttributeName + "\');", element);
	}

	public boolean isVideoPlaying(WebElement element) {
		WebDriver driver = this.ctx.getBean(WebDriver.class);
		boolean isPlaying = (boolean) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].paused === false;", element);
		return isPlaying;
	}

	public void pauseVideo(WebElement element) {
		WebDriver driver = this.ctx.getBean(WebDriver.class);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].pause();", element);
	}

	public void playVideo(WebElement element) {
		WebDriver driver = this.ctx.getBean(WebDriver.class);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].play();", element);
	}

}
