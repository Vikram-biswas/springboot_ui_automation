package com.dt.echo.fe.ui.page.itinfrastructure;

import java.awt.AWTException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.beans.factory.annotation.Autowired;

//import com.dell.titanium.core.TestBase;
import com.dt.echo.fe.ui.page.BaseFactory;
import com.dt.echo.fe.ui.page.home.HomePage;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.annotation.Page;
import com.dt.echo.fe.ui.util.service.CustomActionsService;
import com.dt.echo.fe.ui.util.service.JavaScriptExecutorService;
import com.dt.echo.fe.ui.util.service.RobotClassService;
import com.dt.echo.fe.ui.util.service.UtilService;

@Page
public class ApexIndex extends BaseFactory {
	
	@LazyAutowired
	private CustomActionsService actions;

	@LazyAutowired
	public JavaScriptExecutorService jsExecutor;

	@LazyAutowired
	private RobotClassService robot;

	@LazyAutowired
	protected UtilService util;

	@LazyAutowired
	private HomePage home;
	
	private String portFolioHeaderXpath = "//h3[contains(text(),'?')]/ancestor::div[2]/preceding-sibling::div//a";
	private String portFolioLinkXpath = "//a[contains(@aria-label,'?')]";

	private String ctaListRowHeaders = "//div[contains(@id,'set-?')]//a";
	private String ctaListLinks = "//div[contains(@id,'set-?')]/parent::div/following-sibling::div[1]//div[@tabindex='0']//li[2]//a";
	private String chatWithBusinessAdvisor = "(//span[text()='Chat with a Business Advisor']/ancestor::a)[1]";
	@FindBy(xpath = "//div[contains(@id,'set-')]")
	private List<WebElement> ctaListRows;

	@FindBy(xpath = "//a[text()='View All APEX']")
	private WebElement viewAllApex;

	@FindBy(xpath = "(//a[contains(text(),'APEX')])[2]")
	private WebElement apex;

	@FindBy(xpath = "//span[text()='APEX']")
	private WebElement hoverApex;

	@FindBy(xpath = "//span[text()='IT Infrastructure']")
	private WebElement hoverITInfrastructure;

	@FindBy(xpath = "//button[@id='noButtonIPDell']")
	private WebElement feedback;

	@FindBy(xpath = "//span[text()='Home']/ancestor::li[1]/following-sibling::li//span[text()='Dell APEX']")
	private WebElement dellAPexBreadCrumb;

	@FindBy(xpath = "//div[@id='accordionContent']//h2[@class='heading']")
	private List<WebElement> FAQs;

	@FindBy(xpath = "//a[@title='Arrow previous']")
	private WebElement previousArrow;

	@FindBy(xpath = "//a[@title='Arrow next']")
	private WebElement nextArrow;

	@FindBy(xpath = "//div[@class='carousel-container']//a")
	private List<WebElement> readBlogs;

	@FindBy(xpath = "(//span[text()='Chat with a Business Advisor']/ancestor::a)[1]")
	private WebElement ChatWithBusinessAdvisor;

	@FindBy(xpath = "(//span[text()='Request a Sales Callback']/ancestor::a)[2]")
	private WebElement RequestSalesCallback;

	@FindBy(xpath = "//h3[text()='Request a Sales Callback']")
	public WebElement RequestSalesCallbackHeader;

	@FindBy(xpath = "//a[@title='Close']")
	private WebElement closeRequestSalesCallback;

	@FindBy(xpath = "//a[contains(@aria-label,'Contact Sales by Telephone')]")
	private WebElement callOption;

	@FindBy(xpath = "//span[text()='Get Support']/parent::a")
	public WebElement getSupport;

	@FindBy(xpath = "(//li[contains(@class,'cta-wrapper ')]/a)[1]")
	public WebElement apexMultiCloudLink;

	@FindBy(xpath = "//span[@class='cta-play']/parent::a")
	public WebElement apexMultiCloudVideoPlay;


	public List<WebElement> ctaListRowHeaders(String text) {
		return driver.findElements(By.xpath(ctaListRowHeaders.replace("?", text)));
	}

	public List<WebElement> ctaListLinks(String text) {
		return driver.findElements(By.xpath(ctaListLinks.replace("?", text)));
	}

	public WebElement dynamicXpathWithText(String text) {
		return driver.findElement(By.xpath(portFolioLinkXpath.replace("?", text)));
	}

	public WebElement portFolioHeaderXpath(String text) {
		return driver.findElement(By.xpath(portFolioHeaderXpath.replace("?", text)));
	}

	public WebElement portFolioLinkXpath(String text) {
		return driver.findElement(By.xpath(portFolioLinkXpath.replace("?", text)));
	}

	public WebElement portFolioHeaderCTAList(String text) {
		return portFolioHeaderXpath(text);
	}

	public WebElement portfolioCTAList(String text) {
		return portFolioLinkXpath(text);
	}

	public void chatWithBusinessAdvisor() {
		this.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(chatWithBusinessAdvisor)));
		driver.findElement(By.xpath(chatWithBusinessAdvisor)).click();
		//this.ChatWithBusinessAdvisor.click();
		//this.jsExecutor.forceClick(ChatWithBusinessAdvisor);
	}
	
	public void getSupport() {
		this.getSupport.click();
	}

	public void requestSalesCallback() {
		RequestSalesCallback.click();
	}

	public void closeRequestSalesCallback() {
		closeRequestSalesCallback.click();
	}

	public void callOption() throws InterruptedException, AWTException {
		callOption.click();
		Thread.sleep(3000);
		this.robot.pressEnter();
		Thread.sleep(3000);
	}
	
	public void apexMultiCloudLink() {
		apexMultiCloudLink.click();
	}

	public void apexIndexPage() {
		home.isFeedbackPresent();
		jsExecutor.forceMouseHoverAndClick(hoverITInfrastructure, apex);
		home.isFeedbackPresent();
		this.actions.mouseHover(hoverITInfrastructure).click(apex);
		home.isFeedbackPresent();
	}

	public void clickHyperlink(String text) {
		try {
			this.dynamicXpathWithText(text).click();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public boolean dellAPexBreadCrumb() {
		return this.dellAPexBreadCrumb.isDisplayed();
	}

	public void frequentlyAskedQuestions() {
		this.FAQs.forEach(element -> {
			// this.jsExecutor.forceClick(element);
			element.click();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		});
	}

	public void lastestNewsCtaListArrowsLink() {
		while (this.previousArrow.getAttribute("class").contains("disabled")) {
			this.nextArrow.click();
		}
	}

	public WebElement navigateToCTAHeader(String text) {
		return portFolioHeaderCTAList(text);
	}

	public WebElement navigateToHyperlinks(String text) {
		return dynamicXpathWithText(text);
	}

	public void validateCtaArraws() throws InterruptedException {
		jsExecutor.pageScrollToElement(this.nextArrow);
		if (!this.nextArrow.getAttribute("class").contains("disabled")) {
			do {
				System.out.println("infinite loop running");
				this.nextArrow.click();
				Thread.sleep(1000);
			} while (!this.nextArrow.getAttribute("class").contains("disabled"));

			do {
				this.previousArrow.click();
				Thread.sleep(1000);
			} while (!this.previousArrow.getAttribute("class").contains("disabled"));
		}

	}

	public List<String> readBlogs() {
		List<String> urls = new ArrayList<>();
		readBlogs.forEach(element -> {
			urls.add(element.getAttribute("href"));
		});
		return urls;
	}

	public String getAttributeByValue(String value, String attribute) {
	return jsExecutor.jsExecutorGetAttributeValue(dynamicXpathWithText(value),attribute);
	}
	
	public List<String> apex_portfolio_href_validation() {
		List<String> hrefs = new ArrayList<String>();
		for (int i = 1; i <= ctaListRows.size(); i++) {
			final int index = i;
			ctaListRowHeaders(String.valueOf(index)).forEach(element -> {
				// this.jsExecutor.forceClick(element);
				element.click();
				ctaListLinks(String.valueOf(index)).forEach(ele -> {
					hrefs.add(ele.getAttribute("href"));
				});
			});
		}
		return hrefs;
	}

	public void apex_multiCloud_videoPlay() throws InterruptedException {
		home.isFeedbackPresent();
		home.validateVideoPlay(apexMultiCloudVideoPlay);
	}
}
