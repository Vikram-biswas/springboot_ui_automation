package com.dt.echo.fe.ui.util.config;

import org.springframework.context.annotation.Bean;

import com.dt.echo.fe.ui.util.annotation.LazyConfiguration;
import com.github.javafaker.Faker;

@LazyConfiguration
public class FakerConfig {
	
	@Bean
	public Faker getFaker() {
		return new Faker();
	}

}
