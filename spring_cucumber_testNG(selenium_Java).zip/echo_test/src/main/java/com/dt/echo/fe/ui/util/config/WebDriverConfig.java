package com.dt.echo.fe.ui.util.config;

import org.openqa.selenium.WebDriver;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;

import com.dell.sbtitaniumtestngmvnbddproject.workflows.TestContext;
import com.dt.echo.fe.ui.util.annotation.LazyConfiguration;
import com.dt.echo.fe.ui.util.annotation.ThreadScopeBean;

@LazyConfiguration
public class WebDriverConfig extends TestContext{
	
	@ThreadScopeBean
    @ConditionalOnMissingBean
	public WebDriver chromeDriver() {
		return driver;
	}
}
