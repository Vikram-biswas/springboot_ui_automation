package com.dt.echo.fe.ui.page.echo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.dt.echo.fe.ui.page.BaseFactory;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.annotation.Page;
import com.dt.echo.fe.ui.util.service.BreakpointService;
import com.dt.echo.fe.ui.util.service.JavaScriptExecutorService;
import com.dt.echo.fe.ui.util.service.RobotClassService;
import com.dt.echo.fe.ui.util.service.WindowSwitchService;

@Page
public class BasePage extends BaseFactory {

	@LazyAutowired
	public JavaScriptExecutorService jsExecutor;

	@LazyAutowired
	private WindowSwitchService window;

	@LazyAutowired
	protected BreakpointService breakpoint;

	String submitButton = "//span[text()='Form ?']//ancestor::div[3]//following-sibling::div[3]/button";
	String invalidFielderrorMessage = "//input[@id='?']/following-sibling::p";
	// String backendErrorMessage = "//div[@class='dt-s-error__message']";
	String formFields = "//span[text()='Form ?']//ancestor::div[3]//following-sibling::div[1]//input";
	String formMandateTextFields = "//span[text()='Form ?']//ancestor::div[3]//following-sibling::div[1]//span[@class='dt-c-form__required']/parent::label/following-sibling::input";
	String formMandateFields = "//span[text()='Form ?']//ancestor::div[3]//following-sibling::div[1]//label/span/parent::label/following-sibling::input";
	String locationDropdown = "//span[text()='Form key']//ancestor::div[3]//following-sibling::div[1]//input[@id='country'][@value='?']";

	@FindBy(xpath = "//textarea[@id='FormQuestionNumber1']")
	public WebElement csbFormTextAreaField;

	@FindBy(xpath = "//ul[@role='listbox']/li[1]")
	public WebElement dropdownValue;

	@FindBy(xpath = "//span[contains(text(),'Thank you for contacting Dell.')]")
	public WebElement successMessage;

	@FindBy(xpath = "//ul[contains(@class,'dt-c-list-cta__wrapper')]//a")
	public List<WebElement> ctaLists;

	@FindBy(css = "picture.dt-o-image__picture > :nth-child(9)")
	private WebElement video;

	@FindBy(css = "button.vjs-play-control")
	private List<WebElement> videoplay;

	@FindBy(css = "button.dt-o-button--sidebar > svg")
	private List<WebElement> videoClose;

	@FindBy(css = "button.dt-o-button--sidebar > svg.dt-o-button--download")
	private WebElement videoDownload;

	@FindBy(css = "button.dt-o-button--sidebar > svg.dt-o-button--external")
	private WebElement videoShare;

	@FindBy(css = "button.dt-o-button--sidebar +div.dt-o-social-share-icons > div > a")
	private List<WebElement> videoLinkSocialIcons;

	@FindBy(css = ".dt-o-overlay > embed")
	private List<WebElement> ctaImage;

	@FindBy(xpath = "//div[@class='dt-o-sidebar']/button")
	private List<WebElement> overlayButtons;

	@FindBy(xpath = "//div[@class='dt-o-sidebar']/div/div/a")
	private List<WebElement> overlayShareButtons;
	
	@FindBy(xpath = "//div[contains(@class,'dt-c-list__wrapper-icon')]/span")
	private List<WebElement> listSequencing;
	
	@FindBy(xpath = "//div[contains(@class,'dt-c-list__wrapper-text')]//a")
	private List<WebElement> listLinks;

	public List<WebElement> formMandateFields(String text) {
		return driver.findElements(By.xpath(formMandateFields.replace("?", text)));
	}

	public List<WebElement> formMandateTextFields(String text) {
		return driver.findElements(By.xpath(formMandateTextFields.replace("?", text)));
	}

	public List<WebElement> formFields(String text) {
		return driver.findElements(By.xpath(formFields.replace("?", text)));
	}

	public WebElement invalidFielderrorMessage(String text) {
		return driver.findElement(By.xpath(invalidFielderrorMessage.replace("?", text)));
	}

	public WebElement formSubmitButton(String text) {
		return driver.findElement(By.xpath(submitButton.replace("?", text)));
	}

	public void setResolution(String resolution) {
		breakpoint.setResolution(driver, resolution);
	}

	public WebElement dropdownValue() {
		return dropdownValue;

	}

	public void commentsField() {
		csbFormTextAreaField.sendKeys("Automation testing");
	}

	public boolean isDomAttributePresent(WebElement input, String attribute) {
		try {
			input.getDomAttribute(attribute).toString();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean successMessage() {
		try {
			this.wait.until(ExpectedConditions.elementToBeClickable(successMessage));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean errorMessage(String text) {
		try {
			this.wait.until(ExpectedConditions.elementToBeClickable(invalidFielderrorMessage(text)));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public void validateVideoPlay() throws InterruptedException {
		this.wait.until(ele -> video.isDisplayed());
		video.click();
		System.out.println("waiting for video");
		WebElement video = wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("video")));
		Thread.sleep(5000);
		if (video.isEnabled()) {
			jsExecutor.forceClick(videoplay.get(1));
			System.out.println("video playing");
		}

		Thread.sleep(4000);
		if (jsExecutor.isVideoPlaying(video)) {
			jsExecutor.forceClick(videoplay.get(1));
			System.out.println("video paused");
		}
		Thread.sleep(1000);
		videoShare.click();
		System.out.println("clicking on share link");
		Thread.sleep(2000);
		Assert.assertEquals(validateSocialIcons(videoLinkSocialIcons), true);
		System.out.println("validated on share options");
		Thread.sleep(1000);
		videoClose.get(0).click();
		System.out.println(" video closed");
	}

	public boolean validateSocialIcons(List<WebElement> elements) {
		int size = videoLinkSocialIcons.size();
		System.out.println("size is " + size);
		try {
			if (size == 4) {
				for (int i = 0; i < size - 1; i++) {
					jsExecutor.forceClick(videoLinkSocialIcons.get(i));
					// videoLinkSocialIcons.get(i).click();
					window.switchByIndex(1);
					Thread.sleep(1000);
					driver.getCurrentUrl();
					window.closeWindow(1);
					Thread.sleep(1000);
				}

				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			return false;
		}

	}

	public void defaultLocation(String from, Map<String, String> inputs) {

		inputs.entrySet().stream().forEach(entry -> {

			String url = driver.getCurrentUrl().toString();

			Pattern p = Pattern.compile("[a-z]{2}-[a-z]{2}");
			Matcher m = p.matcher(url);

			StringBuffer currentLocale = new StringBuffer();

			if (m.find()) {
				currentLocale.append(m.group());
			} else {
				System.out.println("No locale match found.");
			}

			driver.navigate().to(url.replace(currentLocale, entry.getKey()));

			String country = wait
					.until(ExpectedConditions.presenceOfElementLocated(
							By.xpath(locationDropdown.replace("?", entry.getValue()).replace("key", from))))
					.getAttribute("value").trim().toString();
			Assert.assertEquals(country.equalsIgnoreCase(entry.getValue()), true);

		});

	}

	public void ctaLinksValidation() throws InterruptedException {
		ctaLists.forEach(element -> {

			String text = element.getText().toString();

			switch (text) {

			case "Content Path":
				break;
			case "With .html":
				break;
			case "With .htm":
				break;
			case "External":
				ctaExternalLink(element);
				break;
			case "Image":
				ctaImageLink(element);
				break;
			case "DT Page":
				ctaDTPageLink(element);
				break;
			case "Partner Portal":
				ctaPPLink(element);
				break;
			default:
				break;
			}

		});
	}

	public void ctaImageLink(WebElement element) {
		element.click();
		wait.until(ExpectedConditions.elementToBeClickable(overlayButtons.get(1)));
		overlayButtons.get(2).click();
		wait.until(ExpectedConditions.elementToBeClickable(overlayShareButtons.get(0)));
		validateSocialIcons(overlayShareButtons);
		Assert.assertEquals(ctaImage.size() >= 1, true);
		overlayButtons.get(0).click();
	}

	public void ctaExternalLink(WebElement element) {
		element.click();
		driver.navigate().back();
	}

	public void ctaDTPageLink(WebElement element) {
		element.click();
		window.switchByIndex(1);
		window.closeWindow(1);
	}

	public void ctaPPLink(WebElement element) {
		element.click();
		window.switchByIndex(1);
		window.closeWindow(1);
	}
	
	public void listSequencing() {
		List<Integer> inSequence = new ArrayList<Integer>();
		List<Integer> outSequence = null;
		listSequencing.forEach(element ->{
			char[] chr = element.getText().toString().toCharArray();
			inSequence.add(Integer.parseInt(String.valueOf(chr[0])));			
		});
		outSequence = inSequence;
		Collections.sort(inSequence);
		Assert.assertEquals(inSequence.equals(outSequence), true);
	}

	public void listLinks() {
		listLinks.forEach(element ->{
			element.click();
			driver.navigate().back();
		});
	}
	
}
