package com.dt.echo.fe.ui.page.home;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.dt.echo.fe.ui.page.BaseFactory;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.annotation.Page;
import com.dt.echo.fe.ui.util.config.WebDriverConfig;
import com.dt.echo.fe.ui.util.service.UtilService;

@Page
public class FindaPartner extends BaseFactory {
	
	
	@LazyAutowired
	private HomePage home;
	
	@LazyAutowired
	private UtilService util;
	
	@LazyAutowired
	private WebDriverConfig config;
	
	@FindBy(xpath = "//a[text()='Find a Partner']")
	private WebElement partnerP;
	
	@FindBy(xpath = "//span[@class='logo-text']")
	private WebElement logoText;
	
	@FindBy(xpath = "//span[text()='Launch now']/ancestor::div[@class='column-side-url']//a")
	private WebElement launchNow;
	
	@FindBy(xpath = "//span[text()='Launch now']/ancestor::div[@class='column-side-url']/preceding-sibling::div/div[2]/a")
	public List<WebElement> getLinkText;
	
	@FindBy(xpath = "//span[text()='Launch now']/ancestor::div[@class='column-side-url']/following-sibling::div/div/a")
	public List<WebElement> addToFavorites;
	
	@FindBy(xpath = "//div[@title='close']")
	public WebElement closeButton;
	
	@FindBy(xpath = "//a[@title='Identify Your Product To See Your Support Options']")
	public WebElement technicalSupport;
	
	@FindBy(xpath = "//a[text()='Accounts Settings page']")
	public WebElement accountSettings;
	
	
	public void navigatePartnerProgram() {
		partnerP.click();
	}
	
	public String getlogoText() {
		return logoText.getText();
	}

}
