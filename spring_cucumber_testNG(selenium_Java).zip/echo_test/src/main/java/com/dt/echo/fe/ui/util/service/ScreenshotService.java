package com.dt.echo.fe.ui.util.service;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import org.apache.commons.imaging.ImageReadException;
import org.apache.commons.imaging.Imaging;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

import com.dell.sbtitaniumtestngmvnbddproject.workflows.TestContext;
import com.dt.echo.fe.ui.page.BaseFactory;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.annotation.LazyConfiguration;
import com.dt.echo.fe.ui.util.config.WebDriverConfig;

@Lazy
@Service
public class ScreenshotService {

	@Value("${screenshot.path}")
	private String path;

	@Autowired
	private UtilService util;
	
	@Autowired
	private ApplicationContext ctx;

	
	public String takeScreenshot() throws IOException {
		File destination = new File(System.getProperty("user.dir") + this.path + this.util.screenshotName());
		File sourceFile = this.ctx.getBean(TakesScreenshot.class).getScreenshotAs(OutputType.FILE);
		FileCopyUtils.copy(sourceFile, destination);
		return destination.toString();
	}

	// This method not in used now
	public void getScreenshot(WebElement element, String path, String fileName) throws IOException, ImageReadException {
		File destination = new File(System.getProperty("user.dir") + this.path + this.util.screenshotName());
		//File sourceFile = this.ctx.getBean(TakesScreenshot.class).getScreenshotAs(OutputType.FILE);
		File screenshot = element.getScreenshotAs(OutputType.FILE);
		FileCopyUtils.copy(screenshot, destination);
		//File baselineImage = new File("baseline-image.png");
        //validateImages(screenshot, baselineImage);
	}
	
	
	@SuppressWarnings("unused")
	private static void validateImages(File screenshotFile, File baselineImage) throws IOException, ImageReadException {
        BufferedImage img1 = Imaging.getBufferedImage(screenshotFile);
        BufferedImage img2 = Imaging.getBufferedImage(baselineImage);

        // Validate dimensions
        if (img1.getWidth() != img2.getWidth() || img1.getHeight() != img2.getHeight()) {
            System.out.println("Images have different dimensions.");
            return;
        }

        // Compare pixel by pixel
        for (int y = 0; y < img1.getHeight(); y++) {
            for (int x = 0; x < img1.getWidth(); x++) {
                if (img1.getRGB(x, y) != img2.getRGB(x, y)) {
                    System.out.println("Images differ at pixel: (" + x + ", " + y + ")");
                    return;
                }
            }
        }

        System.out.println("Images match!");
    }

}
