package com.dt.echo.fe.ui.page.home;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.dt.echo.fe.ui.page.BaseFactory;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.annotation.Page;
import com.dt.echo.fe.ui.util.config.WebDriverConfig;
import com.dt.echo.fe.ui.util.service.JavaScriptExecutorService;
import com.dt.echo.fe.ui.util.service.UtilService;

@Page
public class NewsroomPage extends BaseFactory {

	@LazyAutowired
	protected JavaScriptExecutorService jsExecutor;

	@LazyAutowired
	protected UtilService util;
	
	@LazyAutowired 
	protected HomePage home;

   @LazyAutowired
   private WebDriverConfig config;
	
	private String nRAnnouncementDateRangeXpath = "//span[contains(text(),'?')]/preceding-sibling::input";

	@FindBy(xpath = "//a[text()='Newsroom']")
	private WebElement NewsroomLink;

	@FindBy(xpath = "//span[text()='Newsroom']/ancestor::li/following-sibling::li/span[text()='Overview']")
	private WebElement nROverviewBreadcrumb;

	@FindBy(xpath = "//h1[text()='Dell Technologies Newsroom']")
	private WebElement nRheader1;

	@FindBy(xpath = "//h2[text()='Latest News']")
	private WebElement nRheader2;

	@FindBy(xpath = "//ul[@class='crux-card-grid']//a")
	public List<WebElement> nRhBlogs;

	@FindBy(xpath = "//span[text()='All Announcements']")
	private WebElement nRAllAnnouncements;

	@FindBy(xpath = "//span[text()='Press Kits']")
	private WebElement nRPressKits;

	@FindBy(xpath = "//span[text()='Media Library']")
	private WebElement nRMediaLibrary;

	@FindBy(xpath = "//span[text()='Announcements']/parent::li/preceding-sibling::li//span[text()='Newsroom']/parent::a")
	public WebElement nRAnnouncementsBreadcrumb;

	@FindBy(xpath = "//h1[text()='Announcements']")
	private WebElement nRAnnouncementheader1;

	@FindBy(xpath = "//button[@id='open-filter-button']")
	private WebElement nRAnnouncementFilter;

	@FindBy(xpath = "//span[contains(text(),'?')]/preceding-sibling::input")
	private WebElement nRAnnouncementDateRange;

	@FindBy(xpath = "//span[text()='Press Kits']/parent::li/preceding-sibling::li//span[text()='Newsroom']/parent::a")
	public WebElement nRPressKitsBreadcrumb;

	@FindBy(xpath = "//h2[text()='Press Kits']")
	private WebElement pressKitsHeader2;
	
	@FindBy(xpath = "//span[text()='Media Library']/parent::li/preceding-sibling::li//span[text()='Newsroom']/parent::a")
	public WebElement nRMediaLibraryBreadcrumb;

	@FindBy(xpath = "//h2[text()='Media Library']")
	private WebElement mediaLibrary;
	

	public WebElement nRAnnouncementDateRange(String text) {
		return driver.findElement(By.xpath(nRAnnouncementDateRangeXpath.replace("?", text)));
	}

	public void newsRoomPage() {
		NewsroomLink.click();
	}

	public boolean isbreadcrumbDisplayed() {
		return nROverviewBreadcrumb.isDisplayed();
	}

	public boolean isheader1Displayed() {
		return nRheader1.isDisplayed();
	}

	public boolean isheader2Displayed() {
		return nRheader2.isDisplayed();
	}

	public void nRAllAnnouncementsLink() {
		this.nRAllAnnouncements.click();
	}

	public boolean isnRAnnouncementsBreadcrumbDisplayed() {
		return nRAnnouncementsBreadcrumb.isDisplayed();
	}

	public void nRPressKitsLink() {
		this.nRPressKits.click();
	}

	public boolean isnRPressKitsBreadcrumbDisplayed() {
		return nRPressKitsBreadcrumb.isDisplayed();
	}

	public void nRMediaLibraryLink() {
		this.nRMediaLibrary.click();
	}

	public boolean isnRMediaLibraryBreadcrumbDisplayed() {
		return nRMediaLibraryBreadcrumb.isDisplayed();
	}
	
	public void allnRAnnouncements() throws InterruptedException {
		nRAllAnnouncements.click();
		Thread.sleep(2000);
		this.wait.until(element -> this.nRAnnouncementsBreadcrumb.isDisplayed());

	}

	public void pressKits() throws InterruptedException {
		nRPressKits.click();
		Thread.sleep(2000);
		this.wait.until(element -> this.pressKitsHeader2.isDisplayed());
	}
	
	public void mediaLibrary() throws InterruptedException {
		nRMediaLibrary.click();
		Thread.sleep(2000);
		this.wait.until(element -> this.mediaLibrary.isDisplayed());
	}

}
