package com.dt.echo.fe.ui.page.echo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Service;
import org.testng.Assert;

import com.dt.echo.fe.ui.page.BaseFactory;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.annotation.Page;
import com.dt.echo.fe.ui.util.service.BreakpointService;
import com.dt.echo.fe.ui.util.service.JavaScriptExecutorService;
import com.dt.echo.fe.ui.util.service.PdfContentService;
import com.dt.echo.fe.ui.util.service.UtilService;
import com.dt.echo.fe.ui.util.service.WindowSwitchService;

@Page
public class ContactUs extends BaseFactory {

	@LazyAutowired
	public JavaScriptExecutorService jsExecutor;

	@LazyAutowired
	private WindowSwitchService window;

	@LazyAutowired
	protected BreakpointService breakpoint;
	
	@LazyAutowired
	protected PdfContentService pdf;

	@LazyAutowired
	private UtilService util;

	@FindBy(xpath = "//form[@class='dt-c-form-container']/div[1]//span")
	public WebElement formHeader;

	@FindBy(xpath = "//form[@class='dt-c-form-container']/div[2]//label/following-sibling::input")
	public List<WebElement> formTextFields;

	@FindBy(xpath = "//form[@class='dt-c-form-container']/div[2]//span/parent::label/following-sibling::input")
	public List<WebElement> formTextMandateFields;

	@FindBy(xpath = "//form[@class='dt-c-form-container']/div[2]//label/following-sibling::div/input")
	public List<WebElement> formDropdownFields;

	@FindBy(xpath = "//form[@class='dt-c-form-container']/div[2]//span/parent::label/following-sibling::div/input")
	public List<WebElement> formDropdownMandateFields;

	@FindBy(xpath = "//ul[@role='listbox']/li[1]")
	public WebElement dropdownValue;

	@FindBy(xpath = "//span[@class='dt-c-form__checkbox-custom']")
	public List<WebElement> formCheckBox;

	@FindBy(xpath = "//form[@class='dt-c-form-container']/div[4]/button")
	public WebElement submit;

	@FindBy(xpath = "//span[contains(text(),'Thank you for your interest in Dell.')]")
	public WebElement successMessage;	

	@FindBy(xpath = "//div[@class='dt-c-form__consent-group']//a[contains(@href,'https://')]")
	public List<WebElement> pageHyperlinks;
	
	String fieldError = "//form[@class='dt-c-form-container']/div[2]//label[@for='?']/following-sibling::p";
	String backendErrorMessage = "//div[@class='dt-s-error__message']";
	String defaultCountryDropdown = "//input[@id='country'][@value='?']";


	public void enterTextFields() {
		formTextFields.forEach(element -> {
			element.sendKeys(util.formSubmittion(element.getAttribute("id").toString()));
		});
	}

	public void enterInvalidTextFields() {
		formTextFields.forEach(element -> {
			element.sendKeys(util.formSubmittionInvalidInputs(element.getAttribute("id").toString()));
		});
	}

	public void enterTextMandateFields() {
		formTextMandateFields.forEach(element -> {
			element.sendKeys(util.formSubmittion(element.getAttribute("id").toString()));
		});
	}

	public void enterAllFieldWithRestrictedTextField(String field) {
		formTextFields.forEach(element -> {
			if (element.getAttribute("id").equals(field)) {
				element.sendKeys(util.formSubmittionRestrictedInputs(field));
			}
		});
	}

	public void enterDropdownFields() {
		formDropdownFields.forEach(element -> {
			element.click();
			this.wait.until(ExpectedConditions.elementToBeClickable(dropdownValue));
			dropdownValue.click();
		});
	}

	public void enterDropdownMandateFields() {
		formDropdownMandateFields.forEach(element -> {
			element.click();
			this.wait.until(ExpectedConditions.elementToBeClickable(dropdownValue));
			dropdownValue.click();
		});
	}

	public void checkBox() {
		formCheckBox.forEach(element -> {
			element.click();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
	}

	public boolean successMessage() {
		try {
			this.wait.until(ExpectedConditions.elementToBeClickable(successMessage));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public Map<String, String> invalidErrorMessage() {
		Map<String, String> failedErrorMessages = new HashMap<String, String>();
		
		Map<String, String> requiredFieldErrors = new HashMap<String, String>();
		requiredFieldErrors.put("firstName", "First Name is not valid.");
		requiredFieldErrors.put("lastName", "Last Name is not valid.");
		requiredFieldErrors.put("email", "Business Email is not valid.");
		requiredFieldErrors.put("phoneNumber", "Phone Number is not valid.");
		requiredFieldErrors.put("companyName", "Company Name is not valid.");

		requiredFieldErrors.entrySet().stream().forEach(entry -> {

			String xpath = fieldError.replace("?", entry.getKey());
			String expectedError = entry.getValue();
			String actualError = driver.findElement(By.xpath(xpath)).getText();
			
			if(!expectedError.contains(actualError)) {
				failedErrorMessages.put(expectedError, actualError);
			}
		});
		return failedErrorMessages;
	}

	public Map<String, String> restrictedErrorMessage() {
		Map<String, String> failedErrorMessages = new HashMap<String, String>();
		
		Map<String, String> requiredFieldErrors = new HashMap<String, String>();
		requiredFieldErrors.put("firstName", "First Name contains an invalid value");
		requiredFieldErrors.put("lastName", "Last Name contains an invalid value");
		requiredFieldErrors.put("email", "Business Email contains an invalid value");
		requiredFieldErrors.put("title", "Title contains an invalid value");
		requiredFieldErrors.put("companyName", "Company Name contains an invalid value");

		requiredFieldErrors.entrySet().stream().forEach(entry -> {

			String xpath = fieldError.replace("?", entry.getKey());
			String expectedError = entry.getValue();
			String actualError = driver.findElement(By.xpath(xpath)).getText();
			
			if(!expectedError.contains(actualError)) {
				failedErrorMessages.put(expectedError, actualError);
			}
		});
		return failedErrorMessages;
	}

	public Map<String, String> requiredErrorMessage() {
		Map<String, String> failedErrorMessages = new HashMap<String, String>();
		
		Map<String, String> requiredFieldErrors = new HashMap<String, String>();
		requiredFieldErrors.put("firstName", "First Name is required.");
		requiredFieldErrors.put("lastName", "Last Name is required.");
		requiredFieldErrors.put("email", "Business Email is required.");
		requiredFieldErrors.put("phoneNumber", "Phone Number is required.");
		requiredFieldErrors.put("companyName", "Company Name is required.");
		requiredFieldErrors.put("numberOfEmployees", "Number of Employees is required.");

		requiredFieldErrors.entrySet().stream().forEach(entry -> {

			String xpath = fieldError.replace("?", entry.getKey());

			String expectedError = entry.getValue();

			String actualError = driver.findElement(By.xpath(xpath)).getText();

			//Assert.assertEquals(expectedError.contains(actualError), true);
			if(!expectedError.contains(actualError)) {
				failedErrorMessages.put(expectedError, actualError);
			}

		});
		
		return failedErrorMessages;

	}

	public void defaultLocation(Map<String, String> inputs) {

		inputs.entrySet().stream().forEach(entry -> {

			String url = driver.getCurrentUrl().toString();

			Pattern p = Pattern.compile("[a-z]{2}-[a-z]{2}");
			Matcher m = p.matcher(url);

			StringBuffer currentLocale = new StringBuffer();

			if (m.find()) {
				currentLocale.append(m.group());
			} else {
				System.out.println("No locale match found.");
			}

			driver.navigate().to(url.replace(currentLocale, entry.getKey()));

			String country = wait
					.until(ExpectedConditions
							.presenceOfElementLocated(By.xpath(defaultCountryDropdown.replace("?", entry.getValue())))).getAttribute("value")
					.trim().toString();
			Assert.assertEquals(country.equalsIgnoreCase(entry.getValue()), true);
			
		});

	}
	
	public void hyperlinksValidation(String text) {
		pageHyperlinks.forEach(element ->{
			element.click();
			if(driver.getCurrentUrl().endsWith(".pdf")) {
				pdf.validateTextInPdf(pdf.getPdfContent(driver.getCurrentUrl()).getRight(), text);
			}else {
			 int statusCode = 	util.getUrlStatus(driver.getCurrentUrl());
			 Assert.assertEquals(statusCode, 200);
			}
			driver.navigate().back();
		});
	}

	public void submit() {
		jsExecutor.forceClick(submit);
		//submit.click();
	}

}
