package com.dt.echo.fe.ui.runner;

import java.io.FileReader;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.dell.sbtitaniumtestngmvnbddproject.workflows.APIVerbMethods;
import com.dell.sbtitaniumtestngmvnbddproject.workflows.TestContext;
import com.dt.echo.fe.ui.bdd.CucumberHooks;

import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.FeatureWrapper;
import io.cucumber.testng.PickleWrapper;
import io.cucumber.testng.TestNGCucumberRunner;

@CucumberOptions(features = "@target/failedrerun.txt", glue = { "com.dt.echo.fe.ui.bdd" }, plugin = {"pretty",
		"json:target/cucumber-reports/cucumber.json", "junit:target/cucumber-reports/cucumber.xml", "rerun:target/failedrerun.txt"}, monochrome = true)

public class FailedRerun {
	private TestNGCucumberRunner testNGCucumberRunner;
	public static String jiraupdate = System.getenv("UPDATE_JIRA");

	@BeforeClass(alwaysRun = true)
	public void setUpClass() throws Exception {
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
		TestContext.InitialConfigurations();
		TestContext.AssignData();
	}

	@DataProvider
	public Object[][] scenarios() {
		if (testNGCucumberRunner == null) {
			return new Object[0][0];
		}
		return testNGCucumberRunner.provideScenarios();
	}

	@Test(groups = "cucumber", description = "Runs Cucumber Scenarios", dataProvider = "scenarios")
	public void runScenario(PickleWrapper pickleWrapper, FeatureWrapper featureWrapper) {
		testNGCucumberRunner.runScenario(pickleWrapper.getPickle());
	}
	
	@AfterClass(alwaysRun = true)
	public void tearDownClass() throws Exception {
		testNGCucumberRunner.finish();
		if (jiraupdate.equalsIgnoreCase("yes")) {
		System.out.println("Generating JIRA Execution story with all the testcases mapped");
		String reportPath = "target/cucumber-reports/cucumber.json";
		JSONParser parser = new JSONParser();
		JSONArray jsonObject = (JSONArray) parser.parse(new FileReader(reportPath));
		APIVerbMethods apiVerbMethods = new APIVerbMethods();
		apiVerbMethods.executePOST(TestContext.config.getProperty("xraycucumberapi"), null,
				jsonObject.toJSONString(), "Authorization", TestContext.config.getProperty("authorization"));
	    }
	}
}
