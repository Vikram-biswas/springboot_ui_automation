package com.dt.echo.fe.ui.bdd;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.dell.sbtitaniumtestngmvnbddproject.workflows.TestContext;
//import com.dell.titanium.core.TestBase;
import com.dt.echo.fe.ui.page.home.HomePage;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.service.DevToolsService;
import com.dt.echo.fe.ui.util.service.ScreenshotService;
import com.dt.echo.fe.ui.util.service.UtilService;

import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;

public class CucumberHooks {

	@LazyAutowired
	private UtilService util;

	@LazyAutowired
	private ScreenshotService screenshotService;

	@LazyAutowired
	protected HomePage home;

	@Autowired
	private Environment property;

	@LazyAutowired
	private DevToolsService devTools;

	public static boolean flag = true;
	public static ExtentReports extent = null;
	public static ExtentHtmlReporter extentReport = null;
	public static ExtentTest test = null;
	public Scenario scenario;
	public static String env = System.getenv("TEST_ENVIRONMENT");
	public static String module = System.getenv("MODULE");
	public static String feature = System.getenv("FEATURE");
	public static String url = null;
	public static boolean jiraupdate = false;
	
	@Before(order = 1)
	public void beforeclass(Scenario scenario) throws UnsupportedEncodingException {
		if (flag) {
			flag = false;
			initReportProperties();
			this.util.deleteExistingScreenShots(property.getProperty("screenshot.path"));
		}
		test = CucumberHooks.extent.createTest(scenario.getName());
	}

	@Before(order = 2)
	public void beforeScenario(Scenario scenario) throws FileNotFoundException, IOException, Exception {
		List<String> list = (List<String>) scenario.getSourceTagNames();
		Iterator itr = list.iterator();
		String firstTag = "";
		TestContext.TagName = "";
		while (itr.hasNext()) {
			String tag = itr.next().toString();
			if (firstTag.equalsIgnoreCase(""))
				firstTag = tag;
			if (tag.contains("AEP-")) {
				TestContext.TagName = tag;
				break;
			}
		}
		if (TestContext.TagName.equalsIgnoreCase("")) {
			TestContext.TagName = firstTag;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		TestContext.StartTime = sdf.format(new Date());
		initDriver();
	}

	@After
	public void getResult(Scenario scenario) throws Exception {
		System.out.println(scenario.getStatus());
		TestContext.driver.quit();
		if (scenario.isFailed()) {
			test.fail(MarkupHelper.createLabel(scenario.getName() + "TestCase failed", ExtentColor.RED));
			test.fail("Screenshot below:",
					MediaEntityBuilder.createScreenCaptureFromPath(this.screenshotService.takeScreenshot()).build());
		} else {
			test.pass(MarkupHelper.createLabel(scenario.getName() + "TestCase Passed", ExtentColor.GREEN));
		}

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		TestContext.EndTime = sdf.format(new Date());
		TestContext.jobId = System.getProperty("jobId");
		TestContext.updateSessionId(TestContext.jobId, TestContext.TagName, TestContext.sessionId,
				TestContext.StartTime, TestContext.EndTime, "Cucumber");
	}

	@AfterAll
	public static void cleanup() throws FileNotFoundException, IOException, Exception {
		extent.flush();
	}

	public void initReportProperties() {
		extent = new ExtentReports();
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		extentReport = new ExtentHtmlReporter("./testReports/echo_dt_automation_result.html");
		extentReport.config().setReportName("Regression Test Report");
		extent.attachReporter(extentReport);
	}
	
	public void initDriver() throws FileNotFoundException, IOException, Exception {

		if (property.getProperty("runLocalBrowser").contains("true")) {
			TestContext.getChromeDriver(TestContext.TagName);
			devTools.networkCallLoads(TestContext.driver);
		}else {
			TestContext.getRemoteWebDriver(TestContext.TagName);
		}
		TestContext.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));;
		TestContext.driver.manage().window().maximize();
	}
	
	
	// Below methods are related to background hook scenarios
	@Given("launch the page {string}")
	public void launchToPage(String page) {
		test.log(Status.DEBUG, "Navigating to page");

		try {
			if (env != null) {
				url = property.getProperty("url." + env + "." + module + "." + feature);
				jiraupdate = true;
			} else {
				url = property.getProperty(page.replace("env", property.getProperty("environment")));
			}
			TestContext.driver.get(url);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("url is -> " + url);
		test.log(Status.DEBUG, "Navigated to the Page " + url + ". Test step <font color='green'>SUCCESSFULL</font>");
	}

	@Given("user load the page")
	public void pageScrollDown() {
		test.log(Status.DEBUG, "page scrolling down and up to load the page");
		home.pageScrolldown();
		home.pageScrollup();
		test.log(Status.DEBUG, "page scrolled down & Up. Test step <font color='green'>SUCCESSFULL</font>");
	}

	@Given("feedback dialogue is present")
	public void feedbackPresent() {
		test.log(Status.DEBUG, "Validating and handling if feedback is present");
		home.isFeedbackPresent();
		test.log(Status.DEBUG, "Validated and handled if feedback is present");
	}

}
