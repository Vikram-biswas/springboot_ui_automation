package com.dt.echo.fe.ui.bdd;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.dell.sbtitaniumtestngmvnbddproject.workflows.TestContext;
import com.dt.echo.fe.ui.page.echo.BasePage;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.config.WebDriverConfig;
import com.dt.echo.fe.ui.util.service.UtilService;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

@SuppressWarnings("static-access")
@SpringBootTest
public class BasePageSteps {

	@LazyAutowired
	public BasePage basepage;

	@LazyAutowired
	private CucumberHooks hooks;

	@LazyAutowired
	protected WebDriverWait wait;

	@LazyAutowired
	private UtilService util;

	static List<String> fields = new ArrayList<String>();

	@When("user enters {string} form all the fields")
	public void user_enters_all_the_field_values(String form) {
		hooks.test.log(Status.DEBUG, "form fields to be entered");
		basepage.formFields(form).forEach(element -> {
			if (!basepage.isDomAttributePresent(element, "value")) {
				hooks.test.log(Status.DEBUG, "entering the field -> " + element.getAttribute("id").toString());
				element.sendKeys(util.formSubmittion(element.getAttribute("id").toString()));
			} else {
				element.click();
				this.wait.until(ExpectedConditions.elementToBeClickable(basepage.dropdownValue()));
				basepage.dropdownValue().click();
				hooks.test.log(Status.DEBUG, "selected the field -> " + element.getAttribute("id").toString());
			}
		});
		if (form.equalsIgnoreCase("CSB")) {
			basepage.commentsField();
		}
		hooks.test.log(Status.DEBUG, "form all fields are entered");
	}

	@When("user enters {string} form all the restricted fields")
	public void user_enters_all_the_field_values(String form, DataTable fields) {
		hooks.test.log(Status.DEBUG, "form fields to be entered");

		basepage.formFields(form).forEach(element -> {

			fields.asMap().entrySet().stream().forEach(entry -> {

				if (element.getAttribute("id").contains(entry.getKey())) {

					hooks.test.log(Status.DEBUG, "entering the field -> " + element.getAttribute("id").toString());

					element.sendKeys(entry.getValue().toString());
				}

			});
		});
		if (form.equalsIgnoreCase("CSB")) {
			basepage.commentsField();
		}
		hooks.test.log(Status.DEBUG, "form all fields are entered");
	}

	@When("user enters only mandatory fields for {string} form")
	public void user_enters_only_mandatory_field_values(String form) {
		hooks.test.log(Status.DEBUG, "form fields to be entered");
		basepage.formMandateFields(form).forEach(element -> {
			hooks.test.log(Status.DEBUG, "entering the mandatory field -> " + element.getAttribute("id").toString());
			element.sendKeys(util.formSubmittion(element.getAttribute("id").toString()));
		});
		if (form.equalsIgnoreCase("CSB")) {
			basepage.commentsField();
		}
		hooks.test.log(Status.DEBUG, "form all fields are entered");
	}

	@When("user enters invalid field values in {string} form")
	public void user_enters_invalid_field_values(String form) {
		List<WebElement> ele = new ArrayList<WebElement>();
		hooks.test.log(Status.DEBUG, form + " form invalid fields to be entered");
		basepage.formFields(form).forEach(element -> {
			if (!basepage.isDomAttributePresent(element, "value")) {
				hooks.test.log(Status.DEBUG, "entering the field -> " + element.getAttribute("id").toString());
				fields.add(element.getAttribute("id").toString());
				element.sendKeys(util.formSubmittionInvalidInputs(element.getAttribute("id").toString()));
			}
		});
		hooks.test.log(Status.DEBUG, "form all fields are entered");
	}

	@When("user clicks on {string} submit button")
	public void user_clicks_on_submit_button(String text) {
		hooks.test.log(Status.DEBUG, "form to submit");
		basepage.formSubmitButton(text).click();
		hooks.test.log(Status.DEBUG, "form submitted");
	}

	@Then("validate user receives successful message")
	public void validate_user_receives_successful_message() {
		hooks.test.log(Status.DEBUG, "Validating success message");
		Assert.assertTrue(basepage.successMessage(),
				"Success message is not displayed. Testcase <font color='red'>FAILED</font>");
		hooks.test.log(Status.DEBUG, "Validated success message");
	}

	@Then("validate invalid field error validations for each field")
	public void validate_invalid_field_error_validations_message() {
		hooks.test.log(Status.DEBUG, "Validating error message");
		fields.forEach(field -> {
			Assert.assertTrue(basepage.errorMessage(field),
					"Success message is not displayed. Testcase <font color='red'>FAILED</font>");
			hooks.test.log(Status.DEBUG, "Validated error message for the field -> " + field);
		});
		fields.clear();
	}

	@Then("validate required field error validations for each field in {string} form")
	public void validate_required_field_error_validations_message(String text) {
		hooks.test.log(Status.DEBUG, "Validating required field error message");
		basepage.formMandateTextFields(text).forEach(field -> {
			fields.add(field.getAttribute("id").toString());
		});
		fields.forEach(field -> {
			Assert.assertTrue(basepage.errorMessage(field),
					"Success message is not displayed. Testcase <font color='red'>FAILED</font>");
			hooks.test.log(Status.DEBUG, "Validated error message for the field -> " + field);
		});
		fields.clear();

	}

	@Then("Validate the default location dropdown for {string}")
	public void validate_default_countryValue_validation(String form, DataTable inputs) {
		hooks.test.log(Status.DEBUG, "Validating default location dropdown value");
		basepage.defaultLocation(form, inputs.asMap());
		hooks.test.log(Status.DEBUG, "Validating default location dropdown value");
	}

	@Then("validate each cta link")
	public void validate_each_cta_link() throws InterruptedException {
		hooks.test.log(Status.DEBUG, "Validating cta links");
		basepage.ctaLinksValidation();
		hooks.test.log(Status.DEBUG, "Validated cta links");
	}
	
	@Then("validate each list link")
	public void validate_each_list_link() throws InterruptedException {
		hooks.test.log(Status.DEBUG, "Validating list links");
		basepage.listSequencing();
		basepage.listLinks();
		hooks.test.log(Status.DEBUG, "Validated list links");
	}
	
}
