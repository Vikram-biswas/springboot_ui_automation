package com.dt.echo.fe.ui.runner;

import java.io.FileReader;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.dell.sbtitaniumtestngmvnbddproject.workflows.APIVerbMethods;
import com.dell.sbtitaniumtestngmvnbddproject.workflows.TestContext;
import com.dt.echo.fe.ui.bdd.CucumberHooks;
import com.dt.echo.fe.ui.util.config.WebDriverConfig;

import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.FeatureWrapper;
import io.cucumber.testng.PickleWrapper;
import io.cucumber.testng.TestNGCucumberRunner;

@SuppressWarnings("unused")
@CucumberOptions(features = "features", glue = { "com.dt.echo.fe.ui.bdd" }, tags = "@basepage", dryRun = false, plugin = {
		"json:target/cucumber-reports/cucumber.json", "junit:target/cucumber-reports/cucumber.xml" }, monochrome = true)

public class CucumberRunner {
	private TestNGCucumberRunner testNGCucumberRunner;

	@BeforeClass(alwaysRun = true)
	public void setUpClass() throws Exception {
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
		TestContext.InitialConfigurations();
		TestContext.AssignData();
	}

	@DataProvider
	public Object[][] scenarios() {
		if (testNGCucumberRunner == null) {
			return new Object[0][0];
		}
		return testNGCucumberRunner.provideScenarios();
	}

	@Test(groups = "cucumber", description = "Runs Cucumber Scenarios", dataProvider = "scenarios")
	public void runScenario(PickleWrapper pickleWrapper, FeatureWrapper featureWrapper) {
		testNGCucumberRunner.runScenario(pickleWrapper.getPickle());
	}
	
	@AfterClass(alwaysRun = true)
	public void tearDownClass() throws Exception {
		testNGCucumberRunner.finish();
		if (CucumberHooks.jiraupdate) {
			System.out.println("Generating JIRA Execution story with all the testcases mapped");
			String reportPath = "target/cucumber-reports/Cucumber.json";
			JSONParser parser = new JSONParser();
			JSONArray jsonObject = (JSONArray) parser.parse(new FileReader(reportPath));
			APIVerbMethods apiVerbMethods = new APIVerbMethods();
			apiVerbMethods.executePOST(TestContext.config.getProperty("xraycucumberapi"), null,
					jsonObject.toJSONString(), "Authorization", TestContext.config.getProperty("authorization"));
		}
	}
}
