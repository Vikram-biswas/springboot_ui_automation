package com.dt.echo.fe.ui.bdd;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AlienwareSteps {
	
   //all methods currently in contactUs Steps class

}
