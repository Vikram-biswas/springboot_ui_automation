package com.dt.echo.fe.ui.bdd;

import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.tuple.Pair;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.boot.test.context.SpringBootTest;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.dt.echo.fe.ui.page.echo.BasePage;
import com.dt.echo.fe.ui.page.echo.ContactUs;
import com.dt.echo.fe.ui.page.home.HomePage;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.service.UtilService;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;

@SuppressWarnings("static-access")
@SpringBootTest
public class UtileSteps {
	
	@LazyAutowired
	public ContactUs contactUs;

	@LazyAutowired
	private CucumberHooks hooks;

	@LazyAutowired
	protected WebDriverWait wait;

	@LazyAutowired
	private UtilService util;
	
	@LazyAutowired 
	protected HomePage home;
	
	@LazyAutowired 
	protected BasePage base;
	
	@Then("validate no images broken after pageload")
	public void validate_no_images_broken_after_pageload() {
		hooks.test.log(Status.DEBUG, "Validating broken images after pageload");
		Pair<Boolean, List<String>> brokenImage = home.validateIfImagesAreBroken();
		if (brokenImage.getRight().size() >0) {
			hooks.test.log(Status.DEBUG,
					"Found broken images, below are the link of URL images which didn't load correctly. Test case <font color='red'>FAILED</font>");
			brokenImage.getRight()
					.forEach(brokenImageLink -> hooks.test.log(Status.DEBUG, "Broken image URL : " + brokenImageLink));
			Assert.assertTrue(!brokenImage.getLeft(),
					"Encountered broken Images. Testcase <font color='red'>FAILED</font>");
		} else {
			hooks.test.log(Status.DEBUG,
					"No Broken images in the page, Testcase <font color='green'>SUCCESSFULL</font>");
		}
	}
	
	@Then("Validate the {string} links")
	public void validate_srl_lcs_hyperlinks(String formtype, DataTable pdf) throws InterruptedException {
		hooks.test.log(Status.DEBUG, "Validating all the hyperlinks");
        Optional<String> pdfText = Optional.ofNullable(pdf.asList().get(0));
		base.hyperlinksValidation(formtype, pdfText.orElse("No content available"));
		hooks.test.log(Status.DEBUG, "Validated all the hyperlinks");
	}
	


}
