package com.dt.echo.fe.ui.bdd;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.devtools.v126.input.Input;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.boot.test.context.SpringBootTest;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.dt.echo.fe.ui.page.echo.ContactUs;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.service.UtilService;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

@SuppressWarnings("static-access")
@SpringBootTest
public class ContactUsSteps {
	
	@LazyAutowired
	public ContactUs contactUs;

	@LazyAutowired
	private CucumberHooks hooks;

	@LazyAutowired
	protected WebDriverWait wait;

	@LazyAutowired
	private UtilService util;

	@When("user enters all the fields")
	public void user_enters_all_the_field_values() {
		hooks.test.log(Status.DEBUG, "entering text fields");
		contactUs.enterTextFields();
		hooks.test.log(Status.DEBUG, "entering dropdown fields");
		contactUs.enterDropdownFields();
		hooks.test.log(Status.DEBUG, "selecting check boxes");
		contactUs.checkBox();
		hooks.test.log(Status.DEBUG, "form all fields are entered");
	}

	@When("user enters only mandatory fields for form")
	public void user_enters_only_mandatory_field_values() {
		hooks.test.log(Status.DEBUG, "form fields to be entered");
		contactUs.enterTextMandateFields();
		contactUs.enterDropdownMandateFields();
		hooks.test.log(Status.DEBUG, "form all fields are entered");
	}

	@When("user enters invalid field values in form")
	public void user_enters_invalid_field_values() {
		hooks.test.log(Status.DEBUG, "form invalid fields to be entered");
		contactUs.enterInvalidTextFields();
		contactUs.enterDropdownMandateFields();
		hooks.test.log(Status.DEBUG, "form all fields are entered");
	}

	@When("user clicks on submit")
	public void user_clicks_on_submit_button() {
		hooks.test.log(Status.DEBUG, "form to submit");
		contactUs.submit();
		hooks.test.log(Status.DEBUG, "form submitted");
	}

	@Then("Validate successful message")
	public void validate_user_receives_successful_message() {
		hooks.test.log(Status.DEBUG, "Validating success message");
		Assert.assertEquals(contactUs.successMessage(), true);
		hooks.test.log(Status.DEBUG, "Validated success message");
	}

	@Then("Validate invalid entry field error validations for each field")
	public void validate_invalid_field_error_validations_message() {
		hooks.test.log(Status.DEBUG, "Validating invalid error message");
		contactUs.invalidErrorMessage().entrySet().stream().forEach(entry -> {
			hooks.test.log(Status.DEBUG, "EXPECTED error message is ::: \""+ entry.getKey() + "\"   But ACTUAL error message is ::: \"" + entry.getValue()+"\"");		
		});
		Assert.assertEquals(contactUs.invalidErrorMessage().size()>=1, false);
	}

	@Then("Validate required field error validations for each field")
	public void validate_required_field_error_validations_message() {
		hooks.test.log(Status.DEBUG, "Validating required field error message");
		contactUs.requiredErrorMessage().entrySet().stream().forEach(entry -> {
			hooks.test.log(Status.DEBUG, "EXPECTED error message is ::: \""+ entry.getKey() + "\"   But ACTUAL error message is ::: \"" + entry.getValue()+"\"");		
		});
		Assert.assertEquals(contactUs.requiredErrorMessage().size()>=1, false);
	}
	
	@When("user enters all the fields with restricted")
	public void user_enters_all_the_field_values(DataTable fields) {
		hooks.test.log(Status.DEBUG, "form fields to be entered");
		fields.asList().stream().forEach(field ->{
			contactUs.enterAllFieldWithRestrictedTextField(field);
		});
		hooks.test.log(Status.DEBUG, "form all fields are entered");
	}
	
	@Then("Validate restricted field error validations for each field")
	public void validate_restricted_field_error_validations_message() {
		hooks.test.log(Status.DEBUG, "Validating restricted field error message");
		contactUs.restrictedErrorMessage().entrySet().stream().forEach(entry -> {
			hooks.test.log(Status.DEBUG, "EXPECTED error message is ::: \""+ entry.getKey() + "\"   But ACTUAL error message is ::: \"" + entry.getValue()+"\"");		
		});
		Assert.assertEquals(contactUs.restrictedErrorMessage().size()>=1, false);
	}

	@Then("Validate the default location dropdown")
	public void validate_default_location_dropdown(DataTable inputs) {
		hooks.test.log(Status.DEBUG, "Validating default dropdown location value");
		contactUs.defaultLocation(inputs.asMap());
		hooks.test.log(Status.DEBUG, "Validated default dropdown location value");
	}
	
	@Then("Validate the contactus page hyperlinks")
	public void validate_contactus_page_hyperlinks() {
		hooks.test.log(Status.DEBUG, "Validating all the hyperlinks");
		String pdfText =  "Dell Technologies Inc. Subsidiary List";
		contactUs.hyperlinksValidation(pdfText);
		hooks.test.log(Status.DEBUG, "Validated all the hyperlinks");
	}

}
