package com.dt.echo.fe.ui.bdd;

import java.io.UnsupportedEncodingException;

import org.openqa.selenium.By;
import org.springframework.boot.test.context.SpringBootTest;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.dell.sbtitaniumtestngmvnbddproject.workflows.TestContext;
//import com.dell.titanium.core.TestBase;
import com.dt.echo.fe.ui.page.home.FindaPartner;
import com.dt.echo.fe.ui.page.home.HomePage;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.service.JavaScriptExecutorService;
import com.dt.echo.fe.ui.util.service.ScreenshotService;
import com.dt.echo.fe.ui.util.service.UtilService;
import com.dt.echo.fe.ui.util.service.WindowSwitchService;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

@SuppressWarnings("static-access")
@SpringBootTest
public class FindaPartnerSteps {
	
	@LazyAutowired
	private FindaPartner fap;

	@LazyAutowired
	private ScreenshotService screenshotService;

	@LazyAutowired
	private WindowSwitchService windows;

	@LazyAutowired
	private UtilService util;

	@LazyAutowired
	private JavaScriptExecutorService jsExecutor;

	@LazyAutowired
	private CucumberHooks logs;

	@LazyAutowired
	private HomePage home;
	
	static boolean cookies = true;

	@Given("user navigated to find a partner page")
	public void dtpartnerProgramPage() throws UnsupportedEncodingException {
		logs.test.log(Status.DEBUG, "navigating to partner program page");
		fap.navigatePartnerProgram();
		logs.test.log(Status.DEBUG, "Navigated to partner program page. Test step <font color='green'>SUCCESSFULL</font>");
	}
	
	@Then("validate find a partner links")
	public void ppLinks() {
		if(fap.getLinkText.size()>0) {
			fap.getLinkText.forEach(element -> {
				logs.test.log(Status.DEBUG, "validating the href URLs" + element.getAttribute("href"));
				home.urlValidations.put(element.getAttribute("href"), element.findElement(By.xpath("./div")).getText());
			});
			logs.test.log(Status.DEBUG, "validated the href URLs");
		}
	}
	
	@Then("validate technical support link")
	public void ppTechnicalSupportLinks() {
		logs.test.log(Status.DEBUG, "Validating the technical support link");
		boolean[] flag = { true };
		String originalWindow = TestContext.driver.getWindowHandle();
		fap.technicalSupport.click();
		windows.switchByIndex(1);
		if (!TestContext.driver.getTitle().contains("404")) {
			logs.test.log(Status.DEBUG,
					"Validated the technical support URL :: " + TestContext.driver.getCurrentUrl()
							+ " from raw html lists And found the statuscode as "
							+ util.getUrlStatus(TestContext.driver.getCurrentUrl())
							+ " and the browser title is :: "+ TestContext.driver.getTitle()
							+ ". TestCase <font color='green'>SUCCESSFULL</font>");
		} else {
			flag[0] = false;
			logs.test.log(Status.DEBUG, "Validated the technical support URL :: " + TestContext.driver.getCurrentUrl()
					+ " from raw html lists And found the statuscode as <font color='red'>"
					+ util.getUrlStatus(TestContext.driver.getCurrentUrl()) + "</font. TestCase <font color='red'>FAILED</font>");
		}
		TestContext.driver.close();
		TestContext.driver.switchTo().window(originalWindow);
		Assert.assertTrue(flag[0], "Testcase <font color='red'>FAILED</font>");
	}

	
	@Then("validate account settings link")
	public void ppAccountSettingsLinks() {
		logs.test.log(Status.DEBUG, "Validating the account settings link");
		boolean[] flag = { true };
		fap.accountSettings.click();
		if (!TestContext.driver.getTitle().contains("404")) {
			logs.test.log(Status.DEBUG,
					"Validated the technical support URL :: " + TestContext.driver.getCurrentUrl()
							+ " from raw html lists And found the statuscode as "
							+ util.getUrlStatus(TestContext.driver.getCurrentUrl())
							+ " and the browser title is :: "+ TestContext.driver.getTitle()
							+ ". TestCase <font color='green'>SUCCESSFULL</font>");
		} else {
			flag[0] = false;
			logs.test.log(Status.DEBUG, "Validated the technical support URL :: " + TestContext.driver.getCurrentUrl()
					+ " from raw html lists And found the statuscode as <font color='red'>"
					+ util.getUrlStatus(TestContext.driver.getCurrentUrl()) + "</font. TestCase <font color='red'>FAILED</font>");
		}
		Assert.assertTrue(flag[0], "Testcase <font color='red'>FAILED</font>");
        home.navigateBack();
	}
	
}
