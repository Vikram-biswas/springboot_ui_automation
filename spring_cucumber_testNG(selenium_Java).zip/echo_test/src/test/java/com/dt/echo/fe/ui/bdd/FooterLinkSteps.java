package com.dt.echo.fe.ui.bdd;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.dt.echo.fe.ui.page.home.HomePage;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;

@SuppressWarnings("static-access")
public class FooterLinkSteps {
	
	@LazyAutowired
	private CucumberHooks logs;
	
	@LazyAutowired
	private HomePage home;	
	

	@Then("validate the floating contactUs functionality")
	public void validate_the_contact_us_functionality(DataTable tableList) {
		home.floatingContactUs();
		tableList.asList().forEach(value -> home.dynamicXpathWithContainsText(value).isDisplayed());
		home.floatingContactUs();
	}

	@Then("validate footer links are mapped to correct hrefs")
	public void validate_user_redirected_to_the_correct_page(DataTable tableList) {
		tableList.asMap().entrySet().stream().forEach(entry -> {
			logs.test.log(Status.DEBUG, "Validating footer account links");
			WebElement element = home.dynamicFooterXpath(entry.getKey()).get(0);
			if(home.dynamicFooterXpath(entry.getKey()).size()>1) {
				element = home.dynamicFooterXpath(entry.getKey()).get(1);
			}
			home.pageScrollToElement(element);
			String url = home.jsExecutor.jsExecutorGetAttributeValue(element, "href");			
			home.urlValidations.put(url, entry.getValue());
			logs.test.log(Status.DEBUG, "Validated footer link url "+url+" contains the href in the url title as "+entry.getValue() +".  Testcase <font color='green'>SUCCESSFUL</font>");
			Assert.assertTrue(url.contains(entry.getValue()),"Links did not match with URL. Testcase <font color='red'>FAILED</font>");
		});
	}

}
