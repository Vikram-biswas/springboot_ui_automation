
package com.dt.echo.fe.ui.bdd;

import java.awt.AWTException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
//import com.dell.titanium.core.TestBase;
import com.dt.echo.fe.ui.page.home.HomePage;
import com.dt.echo.fe.ui.page.itinfrastructure.ApexIndex;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.service.PdfContentService;
import com.dt.echo.fe.ui.util.service.ScreenshotService;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.spring.CucumberContextConfiguration;


@SuppressWarnings("static-access")
@CucumberContextConfiguration
@SpringBootTest
public class ApexIndexSteps {
	
	@Autowired
	private CucumberHooks hooks;
	
	@LazyAutowired
	private ApexIndex apex;

	@LazyAutowired
	private ScreenshotService screenshotService;
	
	@LazyAutowired 
	protected HomePage home;
	
	@LazyAutowired
	private PdfContentService pdf;

	static boolean cookies = true;

	@Given("user navigated to apex index page")
	public void dtApexIndexPage() {
		hooks.test.log(Status.DEBUG, "Validating cookies and navigating to apex index page");
		if (cookies) {
			home.ifCookies();
			hooks.test.log(Status.DEBUG, "Found & accepted Cookies");
			cookies = false;
		}
		apex.apexIndexPage();
		hooks.test.log(Status.DEBUG, "Navigated to apex index page. Test step <font color='green'>SUCCESSFULL</font>");
	}
	
	@Then("validate no images broken after pageload")
	public void validate_no_images_broken_after_pageload() {
		hooks.test.log(Status.DEBUG, "Validating broken images after pageload");
		Pair<Boolean, List<String>> brokenImage = home.validateIfImagesAreBroken();
		if (brokenImage.getRight() != null) {
			hooks.test.log(Status.DEBUG,
					"Found broken images, below are the link of URL images which didn't load correctly. Test case <font color='red'>FAILED</font>");
			brokenImage.getRight()
					.forEach(brokenImageLink -> hooks.test.log(Status.DEBUG, "Broken image URL : " + brokenImageLink));
			Assert.assertTrue(!brokenImage.getLeft(),
					"Encountered broken Images. Testcase <font color='red'>FAILED</font>");
		} else {
			hooks.test.log(Status.DEBUG,
					"No Broken images in the page, Testcase <font color='green'>SUCCESSFULL</font>");
		}
	}

	@Then("validate the breadcrumb in apex_index page")
	public void validate_the_breadcrumb_in_apex_index_page() {
		hooks.test.log(Status.DEBUG, "Validating dell apex breadcrumb");
		apex.dellAPexBreadCrumb();
		hooks.test.log(Status.DEBUG, "apex breadcrumd is populating. TestCase <font color='green'>SUCCESSFULL</font>");
	}

	@Then("I navigate to previous page")
	public void revert_back_to_apex_index_page() throws InterruptedException {
		home.navigateBack();
		Thread.sleep(5000);
		hooks.test.log(Status.DEBUG, "Page navigated back");
	}

	@Then("Apex portfolio header is clicked {string}")
	public void apex_portfolio_lists_are_captured(String portfolioHeader) throws InterruptedException {
		hooks.test.log(Status.DEBUG, "Validating portfolio header " + portfolioHeader + " Functionality");
		apex.portFolioHeaderCTAList(portfolioHeader).click();
		Thread.sleep(2000);

	}
	
	@Then("validate Apex portfolio headers and get each portfolio cta list hrefs")
	public void validate_apex_portfolio_hrefs() throws InterruptedException {
		List<String> hrefs = apex.apex_portfolio_href_validation();
		hrefs.forEach(url -> {
			home.urlValidations.put(url, url);
		});		
	}
	
	@Then("validated all the urls")
	public void validate_URLs() throws UnsupportedEncodingException {
		hooks.test.log(Status.DEBUG, "Validating all the URLS by navigating the URL for scenario"+ home.urlValidations.keySet());
		Pair<List<String>, List<Integer>> values = home.urlValidation();
		if(values.getRight()!=null){
			int i = 0;
			while(i<values.getLeft().size()) {
				hooks.test.log(Status.DEBUG, "The URL :: https:"+values.getLeft().get(i)+" is failed. It is return the statuscode as "+values.getRight().get(i)+". TestStep <font color='red'>FAILED</font>");
                i++;
			}
			Assert.assertTrue(values!=null, "TestCase <font color='red'>FAILED</font>");
		}
		home.urlValidations.clear();
	}

	@Then("validate user redirected to the correct hyperlink page")
	public void validate_user_redirected_to_the_correct_page(DataTable tableList) {
		tableList.asMap().entrySet().stream().forEach(entry -> {
			hooks.test.log(Status.DEBUG, "Validating apex page hyperlinks");
			home.pageScrollToElement(apex.navigateToHyperlinks(entry.getKey()));
			String url =  apex.getAttributeByValue(entry.getKey(), "href");
		//	apex.jsExecutor.jsExecutorGetAttributeValue(apex.dynamicXpathWithText(entry.getKey()), "href");
			home.urlValidations.put(url, entry.getValue());
			hooks.test.log(Status.DEBUG, "Validated apex page hyperlink url "+url+" contains the href in the url title as "+entry.getValue() +".  Testcase <font color='green'>SUCCESSFUL</font>");
			Assert.assertTrue(url.contains(entry.getValue()),"Links did not match with URL. Testcase <font color='red'>FAILED</font>");
		});
	}

	@Then("validate each FAQs are expandable")
	public void validate_each_fa_qs_are_expandable() {
		hooks.test.log(Status.DEBUG, "Validating FAQs Functionality");
		apex.frequentlyAskedQuestions();
		hooks.test.log(Status.DEBUG, "Validated FAQs Functionality");
	}

	@When("latest_news_from_dell_apex preview and next arrow is clickable")
	public void latest_news_from_dell_apex_lists_are_captured() throws InterruptedException {
		hooks.test.log(Status.DEBUG, "validating cta list previous and next arrows");
		apex.validateCtaArraws();
		hooks.test.log(Status.DEBUG, "validated cta list previous and next arrows");
	}

	@Then("validate the readBlogs hyperlinks")
	public void validate_the_readBlogs_hyperlinks() {
		hooks.test.log(Status.DEBUG, "validating the readBlogs hyperlinks");
		List<String> records = apex.readBlogs();
			for(int i=0;i<records.size();i++) {
				home.urlValidations.put(records.get(i), records.get(i));
				hooks.test.log(Status.DEBUG, "Adding the URL ::  "+ records.get(i) + " and adding the content :: " + records.get(i));
			}
	}

	@Then("validate the ChatWithBusinessAdvisor functionality")
	public void validate_the_ChatWithBusinessAdvisor_functionality(DataTable tableList) throws InterruptedException {
		hooks.test.log(Status.DEBUG, "validating the ChatWithBusinessAdvisor functionality");
		apex.chatWithBusinessAdvisor();
		tableList.asList().forEach(value -> {
			home.dynamicXpathWithContainsText(value).isDisplayed();
			hooks.test.log(Status.DEBUG, "validated the " + value + " ChatWithBusinessAdvisor functionality");
		});
		Thread.sleep(1000);
		apex.chatWithBusinessAdvisor();
		Thread.sleep(1000);
	}
	
	@Then("validate the RequestSalesCallBack functionality")
	public void validate_the_RequestSalesCallBack_functionality() throws InterruptedException {
		hooks.test.log(Status.DEBUG, "validating the RequestSalesCallBack functionality");
		apex.requestSalesCallback();
		Thread.sleep(1000);
		Assert.assertTrue(apex.RequestSalesCallbackHeader.isDisplayed(),"Few links are broken");
		apex.closeRequestSalesCallback();
		Thread.sleep(1000);
		hooks.test.log(Status.DEBUG, "validated the RequestSalesCallBack functionality");
	}
	
	@Then("validate the call functionality")
	public void validate_the_call_functionality() throws InterruptedException, AWTException {
		hooks.test.log(Status.DEBUG, "validating the call functionality");
		apex.callOption();
		Thread.sleep(1000);
		hooks.test.log(Status.DEBUG, "validated the call functionality");
	}
	
	@Then("validate the getSupport functionality")
	public void validate_the_getSupport_functionality() {
		hooks.test.log(Status.DEBUG, "validating the getSupport functionality");
		apex.getSupport();
		hooks.test.log(Status.DEBUG, "validated the getSupport functionality");
	}
	
	@Then("get the apex readblogs pdf url")
	public void readblogs_apex_pdf_url() {
		hooks.test.log(Status.DEBUG, "validating the pdf url from apex readBlogs hyperlinks");
		List<String> records = apex.readBlogs();
		home.pdfUrl = records.stream().filter(url -> url.contains(".pdf")).toList().get(1);
		hooks.test.log(Status.DEBUG, "validated the pdf url from apex readBlogs hyperlinks");
	}
	
	@Then("validate text {string} in pdf")
	public void validate_text_in_pdf(String text) {
	    Pair<Integer, String> values = pdf.getPdfContent(home.pdfUrl);
	    hooks.test.log(Status.DEBUG, "No of pages in pdf is " + values.getLeft() + "and page content is " + values.getRight());
		Assert.assertTrue(pdf.validateTextInPdf(values.getRight(), text));
		hooks.test.log(Status.DEBUG, "PDF content validation is <font color='green'>SUCCESSFUL</font> ");
	}
	
	@Then("validate the apex multi cloud video play")
	public void validate_apex_multiCloud_videoPlay() throws InterruptedException {
		hooks.test.log(Status.DEBUG, "Navigating to apex multi cloud page");
		apex.apexMultiCloudLink();
	    hooks.test.log(Status.DEBUG, "Navigated to apex multi cloud page and validating apex multi cloud video play");
		apex.apex_multiCloud_videoPlay();
		hooks.test.log(Status.DEBUG, "Validated apex multi cloud video play. TestCase <font color='green'>SUCCESSFUL</font> ");
	}

}