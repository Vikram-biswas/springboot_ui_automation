package com.dt.echo.fe.ui.bdd;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.imaging.ImageReadException;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.dell.sbtitaniumtestngmvnbddproject.workflows.TestContext;
import com.dt.echo.fe.ui.page.echo.BasePage;
import com.dt.echo.fe.ui.page.echo.Powerstore;
import com.dt.echo.fe.ui.page.home.HomePage;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.service.BreakpointService;
import com.dt.echo.fe.ui.util.service.CustomActionsService;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

@SuppressWarnings("static-access")
@SpringBootTest
public class PowerstoreSteps {

	@LazyAutowired
	protected HomePage home;

	@LazyAutowired
	protected BasePage base;

	@LazyAutowired
	private Powerstore ps;

	@LazyAutowired
	private CucumberHooks hooks;

	@Autowired
	private Environment property;

	@When("the screen resolution is {string}")
	public void screen_resolution(String resolution) {
		base.setResolution(resolution);
	}

	@Then("Validate the gss locale and region from header and footer {string}")
	public void validate_the_powerstore_gss_functionality_from_header(String resolution) {

		List<String> headerLocale = ps.headerRegionValidation(resolution);
		hooks.test.log(Status.DEBUG, "Validated header GSS loacale -> " + headerLocale.get(0));
		if (headerLocale.size() > 1) {
			hooks.test.log(Status.DEBUG, "Validated header GSS region -> " + headerLocale.get(1));
		}

		List<String> footerLocale = ps.footerRegionValidation();
		hooks.test.log(Status.DEBUG, "Validated footer GSS loacale -> " + footerLocale.get(0));
		hooks.test.log(Status.DEBUG, "Validated footer GSS country -> " + footerLocale.get(1));
	}

	@Then("Validate the logo text {string}")
	public void Validate_the_logo_text(String text) {
		hooks.test.log(Status.DEBUG, "Validating the logo text value");
		Assert.assertEquals(ps.logoText().contains(text), true);
		hooks.test.log(Status.DEBUG, "Validated the logo text value " + ps.logoText());
	}

	@Then("Validate powerstore subnav header")
	public void Powerstore_subnav_header() {
		hooks.test.log(Status.DEBUG, "Validating the subnav header value");
		Assert.assertEquals(ps.subnavHeader().contains("PowerStore"), true);
		hooks.test.log(Status.DEBUG, "Validated the subnav header value " + ps.subnavHeader());
	}

	@Then("Validate powerstore subnav title")
	public void powerstore_subnav_title() {
		hooks.test.log(Status.DEBUG, "Validating the subnav title powerstore value is selected");
		Assert.assertEquals(ps.subnavTitle(), true);
		hooks.test.log(Status.DEBUG, "Validated the subnav title powerstore value is selected " + ps.subnavTitle());
	}

	@Then("Validate media video link")
	public void media_video_link() throws InterruptedException {
		hooks.test.log(Status.DEBUG, "Validating media video link");
		ps.powerstoreVideoPlay();
		hooks.test.log(Status.DEBUG, "Validated media video link");
	}

	@Then("validate the powserstore GSS functionality for {string} and resolution {string}")
	public void validate_the_powerstore_gss_functionality_from_header(String position, String resolution,
			DataTable tableList) {
		hooks.test.log(Status.DEBUG, "Validating GSS " + position + " Functionality");
		tableList.asList().forEach(val -> {
			List<String> gssLocale = null;
			try {
				gssLocale = new ArrayList<String>(ps.gssValidation(position, val));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			hooks.test.log(Status.DEBUG, " locale validation done for  " + gssLocale.get(0) + " is successfull");
			Assert.assertEquals(gssLocale.get(0).contains(val), true);
			if (resolution.equalsIgnoreCase("desktop")) {
				hooks.test.log(Status.DEBUG, " region validation done for  " + gssLocale.get(1) + " is successfull");
				Assert.assertEquals(gssLocale.get(1).contains(val.split("-")[0]), true);
			}

		});
		hooks.test.log(Status.DEBUG,
				"Validated GSS " + position + " Functionality. Testcase <font color='green'>SUCCESSFULL</font>");
	}

	@Then("Validate each hyperlinks on the sub nav component")
	public void Validate_each_hyperlinks_sub_nav_component() {
		hooks.test.log(Status.DEBUG, "Validating sub nav component hyperlinks");
		Pair<List<String>, List<Integer>> linkValidation = ps.subNavValidation();

		linkValidation.getLeft().forEach(url -> {
			hooks.test.log(Status.DEBUG, "Validating sub nav component hyperlinks " + url);
		});

		linkValidation.getRight().forEach(statuscode -> {
			hooks.test.log(Status.DEBUG, "Validating sub nav component hyperlinks " + statuscode);
			Assert.assertEquals(statuscode == 200, true);
		});

	}

	@Then("Validate all hyperlinks on the page")
	public void Validate_all_hyperlinks_page() {
		hooks.test.log(Status.DEBUG, "Validating all hyperlinks from page");
		Pair<List<String>, List<Integer>> linkValidation = ps.hyperlinksValidation();

		linkValidation.getLeft().forEach(url -> {
			hooks.test.log(Status.DEBUG, "href URL is ->  " + url);
		});

		linkValidation.getRight().forEach(statuscode -> {
			hooks.test.log(Status.DEBUG, "Validating statuscode from above URLs " + statuscode);
			Assert.assertEquals(statuscode == 200, true);
		});

	}

	@Then("validate images url are mapped to correct domain")
	public void Validate_image_urls_domain_page() throws ImageReadException, IOException {
		hooks.test.log(Status.DEBUG, "Validating all hyperlinks from page");

		Pair<List<String>, List<String>> urls = ps.getImageUrls();

		String localEnv = property.getProperty("environment");
		String gitlabEnv = hooks.env;
		String env = null;

		if (gitlabEnv == env) {
			env = localEnv;
		} else {
			env = gitlabEnv;
		}
		if (env.equalsIgnoreCase("prod")) {
			urls.getLeft().forEach(url -> {
				if (url.startsWith("https://") && (url.endsWith(".jpg") || url.endsWith(".png"))) {
					hooks.test.log(Status.DEBUG, "Validating the media Image domain as "
							+ property.getProperty("url.image.media.prod") + " from the image URL domain " + url);
					Assert.assertEquals(url.contains(property.getProperty("url.image.media.prod")), true);
				}
			});

			urls.getRight().forEach(url -> {
				if (url.startsWith("https://") && (url.endsWith(".jpg") || url.endsWith(".png"))) {
					hooks.test.log(Status.DEBUG, "Validating the icon image domain as "
							+ property.getProperty("url.image.icon.prod") + " from the image URL domain " + url);
					Assert.assertEquals(url.contains(property.getProperty("url.image.icon.prod")), true);
				}
			});

		} else {
			urls.getLeft().forEach(url -> {
				if (url.startsWith("https://") && (url.endsWith(".jpg") || url.endsWith(".png"))) {
					hooks.test.log(Status.DEBUG, "Validating the domain as "
							+ property.getProperty("url.image.media.nonprod") + " from the image URL domain " + url);
					Assert.assertEquals(url.contains(property.getProperty("url.image.media.nonprod")), true);
				}
			});

			urls.getRight().forEach(url -> {
				if (url.startsWith("https://") && (url.endsWith(".jpg") || url.endsWith(".png"))) {
					hooks.test.log(Status.DEBUG, "Validating the domain as "
							+ property.getProperty("url.image.icon.nonprod") + " from the image URL domain " + url);
					Assert.assertEquals(url.contains(property.getProperty("url.image.icon.nonprod")), true);
				}
			});
		}

	}

}
