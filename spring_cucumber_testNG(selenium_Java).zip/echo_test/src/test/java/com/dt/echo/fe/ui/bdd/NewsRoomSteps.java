package com.dt.echo.fe.ui.bdd;

import java.io.UnsupportedEncodingException;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.boot.test.context.SpringBootTest;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.dell.sbtitaniumtestngmvnbddproject.workflows.TestContext;
//import com.dell.titanium.core.TestBase;
import com.dt.echo.fe.ui.page.home.HomePage;
import com.dt.echo.fe.ui.page.home.NewsroomPage;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;
import com.dt.echo.fe.ui.util.service.JavaScriptExecutorService;
import com.dt.echo.fe.ui.util.service.ScreenshotService;
import com.dt.echo.fe.ui.util.service.UtilService;
import com.dt.echo.fe.ui.util.service.WindowSwitchService;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

@SuppressWarnings("static-access")
@SpringBootTest
public class NewsRoomSteps  {

	@LazyAutowired
	private NewsroomPage newsR;

	@LazyAutowired
	private ScreenshotService screenshotService;

	@LazyAutowired
	private WindowSwitchService windows;

	@LazyAutowired
	private UtilService util;

	@LazyAutowired
	private JavaScriptExecutorService jsExecutor;

	@LazyAutowired
	private CucumberHooks logs;

	@LazyAutowired
	private HomePage home;

	static boolean cookies = true;

	@Given("user navigated to newsroom index page")
	public void dtNewsRoomIndexPage() throws UnsupportedEncodingException {
		home.navigateToNewsRoom();
		logs.test.log(Status.DEBUG, "Validating cookies and navigating to apex index page");
		if (cookies) {
			home.ifCookies();
			logs.test.log(Status.DEBUG, "Found & accepted Cookies");
			cookies = false;
		}
		newsR.newsRoomPage();
		home.isFeedbackPresent();
		logs.test.log(Status.DEBUG, "Navigated to apex index page. Test step <font color='green'>SUCCESSFULL</font>");
	}

	@Then("validate the breadcrumb in newsroom page")
	public void validate_the_breadcrumb_in_newsroom_page() {
		logs.test.log(Status.DEBUG, "Validating newsroom breadcrumb");
		home.isFeedbackPresent();
		Assert.assertTrue(newsR.isbreadcrumbDisplayed(),
				"Newsroom Breadcrumb is not displaying. Testcase <font color='green'>FAILED</font>");
		logs.test.log(Status.DEBUG,
				"newsroom breadcrumd is populating. TestCase <font color='green'>SUCCESSFULL</font>");
	}

	@Then("validate newsroom headers")
	public void validate_newsroom_haeders() {
		logs.test.log(Status.DEBUG, "Validating newsroom headers");
		Assert.assertTrue(newsR.isheader1Displayed(),
				"Newsroom Breadcrumb is not displaying. Testcase <font color='green'>FAILED</font>");
		Assert.assertTrue(newsR.isheader2Displayed(),
				"Newsroom Breadcrumb is not displaying. Testcase <font color='green'>FAILED</font>");
		logs.test.log(Status.DEBUG, "newsroom headers are populating. TestCase <font color='green'>SUCCESSFULL</font>");
	}

	@Then("validate the blogs from raw html lists")
	public void validate_rawHtml_ctaList() {
		boolean[] flag = { true };
		logs.test.log(Status.DEBUG, "Validating newsroom blogs from raw html lists");
		String originalWindow = TestContext.driver.getWindowHandle();
		newsR.nRhBlogs.forEach(element -> {
			this.jsExecutor.forceClick(element);
			windows.switchByIndex(1);
			if (!TestContext.driver.getTitle().equalsIgnoreCase("404")) {
				logs.test.log(Status.DEBUG,
						"Validated the blog URL :: " + TestContext.driver.getCurrentUrl()
								+ " from raw html lists And found the statuscode as "
								+ util.getUrlStatus(TestContext.driver.getCurrentUrl())
								+ " and the browser title is :: "+ TestContext.driver.getTitle()
								+ ". TestCase <font color='green'>SUCCESSFULL</font>");
			} else {
				flag[0] = false;
				logs.test.log(Status.DEBUG, "Validated the blog URL :: " + TestContext.driver.getCurrentUrl()
						+ " from raw html lists And found the statuscode as <font color='red'>"
						+ util.getUrlStatus(TestContext.driver.getCurrentUrl()) + "</font. TestCase <font color='red'>FAILED</font>");
			}
			TestContext.driver.close();
			TestContext.driver.switchTo().window(originalWindow);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		});
		TestContext.driver.navigate().refresh();
		Assert.assertTrue(flag[0], "Testcase <font color='red'>FAILED</font>");
	}

	@Then("validate the allAnnouncement button")
	public void validate_allAnnouncement_button() throws InterruptedException {
		logs.test.log(Status.DEBUG, "Validating allAnnouncement button");
		newsR.allnRAnnouncements();
		home.isFeedbackPresent();
		logs.test.log(Status.DEBUG,
				"Validated allAnnouncement button. TestCase <font color='green'>SUCCESSFULL</font>");
	}

	@Then("validate the allAnnouncements page")
	public void validate_allAnnouncement_page() throws InterruptedException {
		logs.test.log(Status.DEBUG, "Validating allAnnouncement page");
		jsExecutor.pageScrollBottom();
		Pair<Boolean, List<String>> brokenImage = home.validateIfImagesAreBroken();
		if (brokenImage.getLeft()) {
			logs.test.log(Status.DEBUG,
					"Found broken images, below are the link of URL images which didn't load correctly. Test case <font color='red'>FAILED</font>");
			brokenImage.getRight()
					.forEach(brokenImageLink -> logs.test.log(Status.DEBUG, "Broken image URL : " + brokenImageLink));
			Assert.assertTrue(!brokenImage.getLeft(),
					"Encountered broken Images. Testcase <font color='green'>FAILED</font>");
		} else {
			logs.test.log(Status.DEBUG,
					"No Broken images in the page, Testcase <font color='green'>SUCCESSFULL</font>");
		}
		newsR.nRAnnouncementsBreadcrumb.click();
		logs.test.log(Status.DEBUG, "Validated allAnnouncement page");
	}

	@Then("validate the pressKits button")
	public void validate_pressKits_button() throws InterruptedException {
		logs.test.log(Status.DEBUG, "Validating pressKits button");
		newsR.pressKits();
		home.isFeedbackPresent();
		logs.test.log(Status.DEBUG, "Validated pressKits button. TestCase <font color='green'>SUCCESSFULL</font>");
	}

	@Then("validate the pressKits page")
	public void validate_pressKits_page() throws InterruptedException {
		logs.test.log(Status.DEBUG, "Validating pressKits page");
		jsExecutor.pageScrollBottom();
		Pair<Boolean, List<String>> brokenImage = home.validateIfImagesAreBroken();
		if (brokenImage.getLeft()) {
			logs.test.log(Status.DEBUG,
					"Found broken images, below are the link of URL images which didn't load correctly. Test case <font color='red'>FAILED</font>");
			brokenImage.getRight()
					.forEach(brokenImageLink -> logs.test.log(Status.DEBUG, "Broken image URL : " + brokenImageLink));
			Assert.assertTrue(!brokenImage.getLeft(),
					"Encountered broken Images. Testcase <font color='green'>FAILED</font>");
		} else {
			logs.test.log(Status.DEBUG,
					"No Broken images in the page, Testcase <font color='green'>SUCCESSFULL</font>");
		}
		newsR.nRPressKitsBreadcrumb.click();
		logs.test.log(Status.DEBUG, "Validated pressKits page");
	}

	@Then("validate the mediaLibrary button")
	public void validate_mediaLibrary_button() throws InterruptedException {
		logs.test.log(Status.DEBUG, "Validating mediaLibrary button");
		newsR.mediaLibrary();
		home.isFeedbackPresent();
		logs.test.log(Status.DEBUG, "Validated mediaLibrary button. TestCase <font color='green'>SUCCESSFULL</font>");
	}

	@Then("validate the mediaLibrary page")
	public void validate_mediaLibrary_page() throws InterruptedException {
		logs.test.log(Status.DEBUG, "Validating mediaLibrary page");
		jsExecutor.pageScrollBottom();
		Pair<Boolean, List<String>> brokenImage = home.validateIfImagesAreBroken();
		if (brokenImage.getLeft()) {
			logs.test.log(Status.DEBUG,
					"Found broken images, below are the link of URL images which didn't load correctly. Test case <font color='red'>FAILED</font>");
			brokenImage.getRight()
					.forEach(brokenImageLink -> logs.test.log(Status.DEBUG, "Broken image URL : " + brokenImageLink));
			Assert.assertTrue(!brokenImage.getLeft(),
					"Encountered broken Images. Testcase <font color='green'>FAILED</font>");
		} else {
			logs.test.log(Status.DEBUG,
					"No Broken images in the page, Testcase <font color='green'>SUCCESSFULL</font>");
		}
		newsR.nRMediaLibraryBreadcrumb.click();
		logs.test.log(Status.DEBUG, "Validated mediaLibrary page");
	}

}