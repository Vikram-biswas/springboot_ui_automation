package com.dt.echo.fe.ui.runner;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationTests {
}
