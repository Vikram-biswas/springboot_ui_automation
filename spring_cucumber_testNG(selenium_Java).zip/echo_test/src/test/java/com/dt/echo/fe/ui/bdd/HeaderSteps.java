package com.dt.echo.fe.ui.bdd;

import java.awt.AWTException;

import org.springframework.boot.test.context.SpringBootTest;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.dell.sbtitaniumtestngmvnbddproject.workflows.TestContext;
import com.dt.echo.fe.ui.page.home.HomePage;
import com.dt.echo.fe.ui.util.annotation.LazyAutowired;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;

@SuppressWarnings("static-access")
@SpringBootTest
public class HeaderSteps {
	
	@LazyAutowired
	private CucumberHooks logs;
	
	@LazyAutowired 
	protected HomePage home;	

	@Then("validate the search box functionality by passing the value {string}")
	public void validate_the_search_box_functionality(String value) throws InterruptedException, AWTException {
		logs.test.log(Status.DEBUG, "Validating search box by passing the value :: " + value);
		home.searchBox(value);
		Thread.sleep(5000);
		logs.test.log(Status.DEBUG, "Validating search box is <font color='green'>SUCCESSFULL</font>");
	}
	
	@Then("validate the signIn functionality")
	public void validate_the_signIn_functionality_from_header() throws InterruptedException {
		logs.test.log(Status.DEBUG, "Validating Sign In Functionality");
		home.signIn();
		Thread.sleep(5000);
		logs.test.log(Status.DEBUG, "Validated Sign In Functionality. Testcase <font color='green'>SUCCESSFULL</font>");
	}

	@Then("validate the signOut functionality")
	public void validate_the_signOut_functionality_from_header() throws InterruptedException {
		logs.test.log(Status.DEBUG, "Validating Sign Out Functionality");
		home.signOut();
		Thread.sleep(5000);
		logs.test.log(Status.DEBUG,
				"Validated Sign Out Functionality. Testcase <font color='green'>SUCCESSFULL</font>");
	}
	
	@Then("validate the GSS functionality for {string}")
	public void validate_the_gss_functionality_from_header(String position, DataTable tableList) {
		logs.test.log(Status.DEBUG, "Validating GSS " + position + " Functionality");
		tableList.asLists().forEach(val -> {
			home.gss(position, val.get(0));
			Assert.assertEquals(TestContext.driver.getCurrentUrl().contains(val.get(0)), true);
			logs.test.log(Status.DEBUG, " URL validation for  " + val.get(0)+ " is successfull");
			home.gss(position, val.get(1));
			Assert.assertEquals(TestContext.driver.getCurrentUrl().contains(val.get(1)), true);
			logs.test.log(Status.DEBUG, " URL validation for  " + val.get(1)+ " is successfull");
		});
		logs.test.log(Status.DEBUG,
				"Validated GSS " + position + " Functionality. Testcase <font color='green'>SUCCESSFULL</font>");
	}
	
	@Then("validate the contactUs functionality")
	public void validate_the_contact_us_functionality() {
		logs.test.log(Status.DEBUG, "Validating Contact Us Functionality");
		home.contactUs();
		logs.test.log(Status.DEBUG,
				"Validated Contact Us Functionality. Testcase <font color='green'>SUCCESSFULL</font>");
	}
	
}
